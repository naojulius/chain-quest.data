<template>
    <NavigationTop />
    <div class="mt-20 p-4">
        <slot class="h-[calc(100vh-11rem)]" />
    </div>
    <NavigationBottom />
</template>