import { 
    PagesAuth, 
    PagesAuthLogin, 
    PagesAuthRegister, 
    PagesAuthRegistrationStepAbout, 
    PagesAuthRegistrationStepContact, 
    PagesAuthRegistrationStepDocument, 
    PagesAuthRegistrationStepEmail, 
    PagesAuthRegistrationStepLegalNotice, 
    PagesAuthRegistrationStepPassword,
    PagesAuthRegistrationStepPin,
    PagesAuthRegistrationStepProfile,    
} from "#components";
import { type ComponentOptionsMixin, type DefineComponent, type PublicProps } from 'vue';
import type { LoginReq } from "~/services/user/login-req.service";
export const useAuthStore = defineStore('auth', () => {
    const router = useRouter();

    interface IPage {
        component: DefineComponent<{}, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {} >,
    }

    let isAuthenticated = ref(false);
    let page = ref("index")
    let registerPage = ref("email")
    let registerParentPageData = ref(
        {
            title: "Nouveau!",
            text: "Rejoignez E-Zara, la solution de covoiturage malgache qui connecte les voyageurs."
        }
    )

    let passwordButtonEyeclosed = ref(false)
    const pages: Array<IPage> = [
        {component: PagesAuth},
        {component: PagesAuthLogin},
        {component: PagesAuthRegister},
    ]

    const pagesRegister: Array<IPage> = [
        {component: PagesAuthRegistrationStepEmail},
        {component: PagesAuthRegistrationStepPassword},
        {component: PagesAuthRegistrationStepPin},
        {component: PagesAuthRegistrationStepProfile},
        {component: PagesAuthRegistrationStepDocument},
        {component: PagesAuthRegistrationStepAbout},
        {component: PagesAuthRegistrationStepContact},
        {component: PagesAuthRegistrationStepLegalNotice},

    ]

    const togglePasswordButtonEye = function (){
        passwordButtonEyeclosed.value = !passwordButtonEyeclosed.value;
    }

    const setPasswordButtonEyeclosed = function(state: boolean){
        passwordButtonEyeclosed.value = state;
    }

    const setPage = function (name: string) {
        page.value = name;
    }

    const setRegisterPage =  function (name: string){
        registerPage.value = name;
    }
    const getPage = computed(()=>{
        switch (page.value) {
            case "index":
                return pages[0];
            case "login":
                return pages[1];
            case "register":
                return pages[2];
            default:
                return pages[4];
        }
        
    });
    const getRegisterPage = computed(()=>{
        switch (registerPage.value) {
            case "email":
                registerParentPageData.value =
                    {
                        title: "Rejoignez le mouvement!",
                        text: "Saisissez votre email et connectez-vous à une communauté de covoitureurs engagés."
                    }
                return pagesRegister[0];
            case "password":
                registerParentPageData.value =
                {
                    title: "Prêt à embarquer ?",
                    text: "Créez un mot de passe sûr : 8 caractères minimum avec des lettres, chiffres et symboles."
                }
                return pagesRegister[1];
            case "pin":
                registerParentPageData.value =
                {
                    title: "Code reçu?",
                    text: "Saisissez le code à 5 chiffres envoyé à votre email pour valider votre inscription."
                }
                return pagesRegister[2];
            case "profile":
                registerParentPageData.value =
                {
                    title: "Une touche perso!",
                    text: "Ajoutez une photo et une bio pour des trajets plus conviviaux et sécurisés."
                }
                return pagesRegister[3];
            case "document":
                registerParentPageData.value =
                {
                    title: "Sécurisons vos trajets",
                    text: "Pour votre sécurité et celle des autres, veuillez fournir les documents nécessaires:"
                }
                return pagesRegister[4];
            case "about":
                    registerParentPageData.value =
                    {
                        title: "Qui êtes-vous ?",
                        text: "Partagez quelques informations essentielles pour compléter votre profil en toute sécurité. Vos données personnelles resteront protégées."
                    }
                    return pagesRegister[5];
            
            case "contact":
                    registerParentPageData.value =
                    {
                        title: "Numéro de téléphone",
                        text: "Ajoutez votre numéro pour sécuriser votre compte et faciliter les échanges avec les covoitureurs."
                    }
                    return pagesRegister[6];


            case "legalnotice":
                registerParentPageData.value =
                {
                    title: "Mentions Legale",
                    text: ""
                }
                return pagesRegister[7];
                
            default:
                return pagesRegister[0];
        }
        
    });
    const checkPassWord = (data: any) =>{
        if(data.password.lenght <= 8){
            return {
                valid: false, 
                title: "Erreur",
                text: "Mots de passe trop court!"
            }
        }

        if(data.password != data.passwordConfirm){
            return {
                valid: false, 
                title: "Erreur",
                text: "Mots de non identique!"
            }
        }
        return {
            valid: true,
            title: '',
            text: '',
        }
    }
    const checkEmail = (email: string): boolean =>{
        return  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    const login = function(loginReq: LoginReq){
        const user = useCookie<{ id: number; name: string }>('user', { maxAge: 60 * 60 * 24 })
        user.value = { id: 1, name: 'John Doe' }
        router.push({ path: "/" })
    }
    const logout = function(){
        let user = useCookie<{ id: number; name: string } | null>('user')
        user.value = null;
        router.push({ path: "/" })
    }

    const acceptLegalNotice = function (){
        const user = useCookie<{ id: number; name: string }>('user', { maxAge: 60 * 60 * 24 }) // 1 day
        user.value = { id: 1, name: 'John Doe' }
        router.push({ path: "/" })
    }
    return {
        setPage, 
        getPage, 
        setRegisterPage, 
        getRegisterPage, 
        registerParentPageData,
        togglePasswordButtonEye, 
        passwordButtonEyeclosed, 
        setPasswordButtonEyeclosed,
        checkPassWord,
        checkEmail, 
        isAuthenticated,
        acceptLegalNotice,
        login, 
        logout
    }
});