<template>
  <NuxtLayout>
    <NuxtPage />
  </NuxtLayout>
  <CommonLoaderMain />
  <Toaster />
</template>
<script lang="ts" setup>
  import { Toaster } from '@/components/ui/sonner'
  const authToken = useCookie('user');
  const router = useRouter();

  watchEffect(() => {
  if (!authToken.value) {
    useAuthStore().setPage('index');
    router.push('/auth');
  }
});
</script>
