<template>
    <ScrollArea class="poppins-regular">
        <!-- HEADER -->
    <header class="text-gray-700 py-6 text-center">
        <h1 class="text-2xl font-bold poppins-bold">Conditions Générales d'Utilisation</h1>
        <p class="text-lg poppins-regular">Dernière mise à jour : <span class="font-semibold">[DATE]</span></p>
    </header>

    <!-- CONTAINER -->
    <main class="max-w-4xl mx-auto p-6 bg-white shadow-md rounded-lg mt-6">
        <section>
            <h2 class="text-2xl font-semibold text-yellow-500">1. Objet des Conditions Générales</h2>
            <p class="mt-2">Les présentes CGU définissent les droits et obligations des utilisateurs de <span class="font-semibold">[Nom de l'Application]</span> en matière de covoiturage.</p>
        </section>

        <section class="mt-6">
            <h2 class="text-2xl font-semibold text-yellow-500">2. Inscription et Compte Utilisateur</h2>
            <ul class="list-disc pl-6 mt-2 space-y-2">
                <li>Vous devez avoir **18 ans** minimum pour vous inscrire comme conducteur.</li>
                <li>Votre **permis de conduire et assurance** doivent être valides.</li>
                <li>Votre compte est **personnel** et ne doit pas être partagé.</li>
            </ul>
        </section>

        <section class="mt-6">
            <h2 class="text-2xl font-semibold text-yellow-500">3. Fonctionnement du Service</h2>
            <p class="mt-2">L’application met en relation conducteurs et passagers pour organiser des trajets de covoiturage.</p>
            <ul class="list-disc pl-6 mt-2 space-y-2">
                <li>Le prix des trajets est affiché avant la réservation.</li>
                <li>Les paiements peuvent être effectués via **carte bancaire ou portefeuille électronique**.</li>
                <li>Les annulations peuvent entraîner des **frais** selon le délai.</li>
            </ul>
        </section>

        <section class="mt-6">
            <h2 class="text-2xl font-semibold text-yellow-500">4. Sécurité et Règles de Conduite</h2>
            <p class="mt-2">Tous les utilisateurs doivent respecter les règles de sécurité :</p>
            <ul class="list-disc pl-6 mt-2 space-y-2">
                <li>Les conducteurs doivent respecter le **code de la route** et ne pas être sous l’influence d’alcool ou de drogues.</li>
                <li>Les passagers doivent être ponctuels et respecter les règles de courtoisie.</li>
                <li>Tout comportement inapproprié peut entraîner **une suspension de compte**.</li>
            </ul>
        </section>

        <section class="mt-6">
            <h2 class="text-2xl font-semibold text-yellow-500">5. Assurance et Responsabilité</h2>
            <p class="mt-2">Chaque conducteur est tenu d’avoir une **assurance automobile valide** couvrant les passagers.</p>
            <p class="mt-2">**[Nom de l'Application]** n’est pas responsable des retards, accidents ou incidents lors des trajets.</p>
        </section>

        <section class="mt-6">
            <h2 class="text-2xl font-semibold text-yellow-500">6. Protection des Données Personnelles</h2>
            <p class="mt-2">Nous protégeons vos données et nous nous engageons à ne jamais les vendre à des tiers.</p>
            <p class="mt-2">Consultez notre <a href="#" class="text-yellow-500 font-semibold underline">Politique de Confidentialité</a> pour en savoir plus.</p>
        </section>

        <section class="mt-6">
            <h2 class="text-2xl font-semibold text-yellow-500">7. Suspension et Résiliation</h2>
            <p class="mt-2">Votre compte peut être suspendu en cas de :</p>
            <ul class="list-disc pl-6 mt-2 space-y-2">
                <li>Violation des règles de sécurité ou fraude.</li>
                <li>Comportement inapproprié envers les autres utilisateurs.</li>
            </ul>
        </section>

        <section class="mt-6">
            <h2 class="text-2xl font-semibold text-yellow-500">8. Contact</h2>
            <p class="mt-2">Pour toute question ou assistance, contactez-nous :</p>
            <ul class="mt-2">
                <li>📧 <a href="mailto:support@nomdelapplication.com" class="text-yellow-500 font-semibold underline">support@nomdelapplication.com</a></li>
                <li>📞 <a href="tel:+XX XXX XXX XXX" class="text-yellow-500 font-semibold underline">+XX XXX XXX XXX</a></li>
            </ul>
        </section>
    </main>

    <!-- FOOTER -->
    <footer class="text-center text-gray-500 text-sm mt-6 pb-6">
        © 2024 [Nom de l'Application]. Tous droits réservés.
    </footer>
    </ScrollArea> 
</template>

<script setup lang="ts">
import { ScrollArea } from '@/components/ui/scroll-area'
</script>