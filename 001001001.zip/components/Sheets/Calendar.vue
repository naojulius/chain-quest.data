<script setup lang="ts">
const props = defineProps({
  trip: {
    required: true,
    type: Object,
    default: () => ({})
  },
})
const formatTime = (isoString: string): string => isoString.slice(11, 16);
const getFormattedTripDate = (begin_time: string, end_time: string): string => {
  const options: Intl.DateTimeFormatOptions = { day: "numeric", month: "short" };

  const startDate = new Date(begin_time);
  const endDate = new Date(end_time);

  const startFormatted = startDate.toLocaleDateString("fr-FR", options).replace(".", ""); // "17 janv"
  const endFormatted = endDate.toLocaleDateString("fr-FR", options).replace(".", ""); // "18 janv"

  return startFormatted === endFormatted ? startFormatted : `${startFormatted} - ${endFormatted}`;
};

import { ScrollArea, ScrollBar  } from '@/components/ui/scroll-area'
import { VisuallyHidden } from 'radix-vue'
import { ArrowLeft, ArrowRight, ChevronLeft, ChevronRight, CalendarX2} from 'lucide-vue-next'
import {
  Dialog,
  DialogContent,
  DialogTrigger,
  DialogDescription,
  DialogTitle,
} from '@/components/ui/dialog'
</script>
<style>
  #dialog-close{
    display: none !important;
  }
</style>
<template>
  <Dialog>
    <DialogTrigger as-child>
      <div class="py-2 inline-flex gap-2 w-full  bg-gray-100 px-2 py-6">
                    <div class="text-xl poppins-bold text-gray-700 w-1/4 flex flex-row gap-1 items-center">
                        <div :class="['w-[10px] h-3/4 bg-green-500 rounded-full items-center justify-between', props.trip.trip_type == 'return'? 'bg-red-300':'bg-green-300']"></div>
                        <div class="flex flex-col items-center justify-center border-gray-300 border-r-2 w-full">
                            <span>
                                {{ formatTime(props.trip.begin_time) }}
                            </span>
                            <span>
                                {{ formatTime(props.trip.end_time) }}
                            </span>
                        </div>
                    </div>
                    <div class="text-lg poppins-regular w-3/4">
                        {{ trip.description }}
                    </div>
                </div>
    </DialogTrigger>
    <DialogContent class="h-full w-full bg-gray-200">
      <div class="w-full absolute  left-0 top-0 bg-gray-300 h-60 bg-[url(/mocks/car-1.jpeg)] bg-cover bg-norepeat rounded-2xl">
        <DialogClose as-child>
        <div class="inline-flex justify-between items-center gap-2 p-2 bg-white mt-4 ml-2 rounded-full bg-opacity-50">
            
              <button>
                  <ArrowLeft  class="size-6 text-gray-700"/>
              </button>
           
            <span class="text-xl text-gray-700 poppins-regular uppercase ">{{getFormattedTripDate(props.trip.begin_time, props.trip.end_time)}}</span>
          </div>
        </DialogClose>
      </div>
      <VisuallyHidden>
        <DialogTitle></DialogTitle>
      </VisuallyHidden>
      <DialogDescription >
        <PagesHomeCalendarTripDetails />
    </DialogDescription>
    </DialogContent>
  </Dialog>
</template>