<script lang="ts" setup>
    import { LoaderCircle } from 'lucide-vue-next';
</script>
<template>
    <div class="size-full flex justify-center items-center flex-col gap-2">
        <LoaderCircle class="size-12 text-gray-700 animate-spin" />
    </div>
</template>