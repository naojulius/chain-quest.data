<!-- <template>
    <div class="w-full rounded-xl overflow-hidden">
        <img src="/mocks/R.jpeg" alt="" class="size-full">
    </div>
    <div class="w-full h-20 flex items-center  justify-center gap-2">
        <Star class="fill-yellow-500 text-yellow-600 size-10" />
        <Star class="fill-yellow-500 text-yellow-600 size-10" />
        <Star class="fill-yellow-500 text-yellow-600 size-10" />
        <Star class="fill-yellow-500 text-yellow-600 size-10" />
        <Star class="fill-yellow-500 text-yellow-600 size-10" />
    </div>

    <div class="h-full w-full flex flex-col gap-2">
        <div class="w-full bg-gray-200 rounded-xl p-4">
            <div class="text-xl poppins-bold text-gray-700">Ride History & Stats</div>
            <div class="flex-col flex ">
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Rides completed</span>
                    <span class="poppins-regular text-xl">125</span>
                </div>
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Punctuality Score</span>
                    <span class="poppins-regular text-xl">95%</span>
                </div>
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Ride Acceptance Rate</span>
                    <span class="poppins-regular text-xl">95%</span>
                </div>
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Ride Cancellation Rate</span>
                    <span class="poppins-regular text-xl">5%</span>
                </div>
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Safety Score</span>
                    <span class="poppins-regular text-xl">100%</span>
                </div>
            </div>
        </div>
        <div class="w-full bg-gray-200 rounded-xl p-4">
            <div class="text-xl poppins-bold text-gray-700">Travel Policy</div>
            <div class="flex-col flex ">
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Pet Allowed</span>
                    <span class="poppins-regular text-xl">Yes</span>
                </div>
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Smoking Policy </span>
                    <span class="poppins-regular text-xl">Allowed</span>
                </div>
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Chat Preferences</span>
                    <span class="poppins-regular text-xl">Talkative</span>
                </div>
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Music Volume</span>
                    <span class="poppins-regular text-xl">Low</span>
                </div>
            </div>
        </div>
    </div>
</template>
<script lang="ts" setup>
import {
    Star
 } from 'lucide-vue-next';
</script> -->
<template>
    <div class="w-full h-full">
        <div class="w-full  flex flex-col gap-2 justify-center items-center">
            <div
                class="border-4 border-yellow-500 size-32 bg-gray-200 rounded-full bg-[url(/mocks/R.jpeg)] bg-cover bg-no-repeat bg-center">
            </div>
            <span class="poppins-bold font-bold text-xl text-yellow-700">Nao Julius</span>
        </div>
        <div class="w-full flex items-center  justify-center gap-2">
            <Star class="fill-yellow-500 text-yellow-600 size-8" />
            <Star class="fill-yellow-500 text-yellow-600 size-8" />
            <Star class="fill-yellow-500 text-yellow-600 size-8" />
            <Star class="fill-yellow-500 text-yellow-600 size-8" />
            <Star class="fill-yellow-500 text-yellow-600 size-8" />
        </div>
        <div class="w-full  flex flex-row gap-2 justify-center items-center pt-4">
            <div class="size-24 bg-gray-100 rounded-xl flex flex-col items-center justify-center">
                <span class="text-2xl poppins-bold">
                    158
                </span>
                <span class="text-xs poppins-regular">
                    completed
                </span>
            </div>
            <div class="size-24 bg-gray-100 rounded-xl flex flex-col items-center justify-center">
                <span class="text-2xl poppins-bold">
                    95 %
                </span>
                <span class="text-xs poppins-regular">
                    Punctuality
                </span>
            </div>
            <div class="size-24 bg-gray-100 rounded-xl flex flex-col items-center justify-center">
                <span class="text-2xl poppins-bold">
                    95 %
                </span>
                <span class="text-xs poppins-regular">
                    Safety
                </span>
            </div>
        </div>
        <div class="h-full w-full pt-10">
            <div class="h-4/5 bg-yellow-500 rounded-t-2xl p-2 ">
                <div class="w-full bg-gray-200 rounded-xl p-4">
                  
                    <div class="flex-col flex gap-2">
                        <div class="text-xl poppins-bold text-gray-700">Travel Policy</div>
                        <div class="py-1 inline-flex items-center justify-between w-full">
                            <span class="poppins-regular text-lg">Pet Allowed</span>
                            <span class="poppins-regular text-lg">Yes ></span>
                        </div>
                        <div class="py-1 inline-flex items-center justify-between w-full">
                            <span class="poppins-regular text-lg">Smoking Policy </span>
                            <span class="poppins-regular text-lg">Allowed ></span>
                        </div>
                        <div class="py-1 inline-flex items-center justify-between w-full">
                            <span class="poppins-regular text-lg">Chat Preferences</span>
                            <span class="poppins-regular text-lg">Talkative ></span>
                        </div>
                        <div class="py-1 inline-flex items-center justify-between w-full">
                            <span class="poppins-regular text-lg">Music Volume</span>
                            <span class="poppins-regular text-lg">Low ></span>
                        </div>
                    </div>
                    <div class="flex-col flex gap-2 pt-4">
                        <div class="text-xl poppins-bold text-gray-700">Travel Policy</div>
                        <div class="py-1 inline-flex items-center justify-between w-full">
                            <span class="poppins-regular text-lg">Pet Allowed</span>
                            <span class="poppins-regular text-lg">Yes ></span>
                        </div>
                        <div class="py-1 inline-flex items-center justify-between w-full">
                            <span class="poppins-regular text-lg">Smoking Policy </span>
                            <span class="poppins-regular text-lg">Allowed ></span>
                        </div>
                        <div class="py-1 inline-flex items-center justify-between w-full">
                            <span class="poppins-regular text-lg">Chat Preferences</span>
                            <span class="poppins-regular text-lg">Talkative ></span>
                        </div>
                        <div class="py-1 inline-flex items-center justify-between w-full">
                            <span class="poppins-regular text-lg">Music Volume</span>
                            <span class="poppins-regular text-lg">Low ></span>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</template>
<script setup lang="ts">
import { Star } from 'lucide-vue-next'
</script>