<script lang="ts" setup>
import { LoaderCircle } from 'lucide-vue-next';
const carpooling = ref([])
</script>
<template>
    DETSAILS
</template>