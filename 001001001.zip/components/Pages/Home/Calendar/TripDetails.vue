<template>
    <ScrollArea class="h-full mt-60 w-full">
        <div class="w-full  rounded-xl p-4">
            <!-- Trip Header -->
            <div class="flex items-center justify-between">
                <h2 class="text-2xl font-semibold poppins-regular">
                {{ trip.start_point.city }} → {{ trip.end_point.city }}
                </h2>
                <span class="bg-green-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                {{ trip.price }} {{ trip.currency }}
                </span>
            </div>
        
            <!-- Trip Date & Time -->
            <div class="text-gray-600 text-sm mt-2">
                <span class="uppercase">{{ getFormattedTripDate(trip.begin_time, trip.end_time) }}</span> ·
                <span>{{ formatTime(trip.begin_time) }} - {{ formatTime(trip.end_time) }}</span> ·
                <span class="text-blue-500">{{ trip.duration }}</span>
            </div>
        
            <!-- Route Details -->
            <div class="mt-4 bg-gray-100 rounded-lg p-4">
                <div class="flex items-center gap-3">
                <Map class="w-6 h-6 text-gray-600" />
                <div>
                    <h4 class="text-sm font-semibold">{{ trip.start_point.city }}</h4>
                    <p class="text-gray-500 text-xs">{{ trip.start_point.address }}</p>
                </div>
                </div>
        
                <div v-if="trip.stops.length > 0">
                <div class="border-l-2 border-gray-300 ml-3 my-2 h-6"></div>
                <div v-for="stop in trip.stops" :key="stop.city" class="flex items-center gap-3 ml-3">
                    <Map class="w-5 h-5 text-yellow-500" />
                    <div>
                    <h4 class="text-sm font-semibold">{{ stop.city }}</h4>
                    <p class="text-gray-500 text-xs">{{ stop.address }}</p>
                    </div>
                </div>
                </div>
        
                <div class="border-l-2 border-gray-300 ml-3 my-2 h-10"></div>
        
                <div class="flex items-center gap-3">
                <Map class="w-6 h-6 text-green-500" />
                <div>
                    <h4 class="text-sm font-semibold">{{ trip.end_point.city }}</h4>
                    <p class="text-gray-500 text-xs">{{ trip.end_point.address }}</p>
                </div>
                </div>
            </div>
        
            <!-- Driver Info -->
            <div class="mt-6 flex items-center gap-4 bg-gray-50 p-4 rounded-lg">
                <img :src="'/mocks/R.jpeg'" class="size-14 rounded-full" alt="Driver Avatar" />
                <div>
                <h3 class="text-lg font-semibold">{{ trip.driver.name }}</h3>
                <p class="text-gray-600 text-sm flex items-center">
                    ⭐ {{ trip.driver.rating }} · 🚗 {{ trip.driver.vehicle.brand }} {{ trip.driver.vehicle.model }}
                </p>
                </div>
            </div>
        
            <!-- Payment Methods -->
            <div class="mt-6">
                <h3 class="text-lg font-semibold">Moyens de paiement</h3>
                <div class="flex space-x-2 mt-2">
                <span v-for="method in trip.payment_methods" :key="method" class="px-3 py-1 bg-gray-200 text-sm rounded-full">
                    {{ method }}
                </span>
                </div>
            </div>
        
            <!-- Booking Button -->
            <div class="mt-6">
                <button class="w-full bg-blue-500 text-white py-3 rounded-lg font-semibold hover:bg-blue-600 transition">
                Réserver ce trajet
                </button>
            </div>
        </div>
    </ScrollArea>
  </template>
  <script setup lang="ts">
  import { ref } from "vue";
  import { Map, Timer, Star } from 'lucide-vue-next'
  import { RegisteredTracksMock } from "~/public/mocks/tracks/registered.tracks";
  import { useRoute } from "vue-router"
import { ScrollArea } from '@/components/ui/scroll-area'

  
const route = useRoute();
let t = RegisteredTracksMock.find(t => t.id === Number(1));
  const trip = ref(t as any);
  
  // Format Date (17 Janv - 18 Janv)
  const getFormattedTripDate = (begin: string, end: string) => {
    const options: Intl.DateTimeFormatOptions = { day: "numeric", month: "short" };
    const startDate = new Date(begin).toLocaleDateString("fr-FR", options).replace(".", "");
    const endDate = new Date(end).toLocaleDateString("fr-FR", options).replace(".", "");
    return startDate === endDate ? startDate : `${startDate} - ${endDate}`;
  };
  
  // Format Time (HH:mm)
  const formatTime = (time: string) => new Date(time).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  
  </script>
  