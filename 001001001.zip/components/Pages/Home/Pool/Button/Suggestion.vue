<template>
    <div class="w-[250px]">
        <img src="/mocks/car-1.jpeg" class="w-full h-auto object-cover rounded-t-lg" alt="">
        <div class="text-2xl poppins-regular text-gray-700 py-2">
            Jack russel
        </div>
        <div class="poppins-regular text-md">
            De Antanimena juqu'a Ankorondrano
        </div>
        <div class="w-full inline-flex items-center justify-between text-gray-700 py-2">
            <div class="inline-flex flex-nowrap items-center justify-start gap-2">
                <Timer clas="size-10" />
                <span class="text-xl">2h</span>
            </div>
            <div class="inline-flex flex-nowrap items-center justify-start gap-2">
                <Star clas="size-10" />
                <span class="text-xl">4.5</span>
            </div>
            <div class=" inline-flex flex-nowrap items-center justify-start gap-2">
                <img src="/vehicles/bicycle.svg" class="size-8" />
            </div>
        </div>
    </div>
</template>
<script setup lang="ts">
import { useRouter } from 'vue-router'
import {Timer, Star} from 'lucide-vue-next'
</script>