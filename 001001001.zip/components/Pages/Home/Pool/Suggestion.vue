<script setup lang="ts">
import { VisuallyHidden } from 'radix-vue'
import { ArrowLeft, Cog, BellRing, Star, Timer } from 'lucide-vue-next'
import {
    Dialog,
    DialogContent,
    DialogTrigger,
    DialogDescription,
    DialogTitle,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import {
  NumberField,
  NumberFieldContent,
  NumberFieldDecrement,
  NumberFieldIncrement,
  NumberFieldInput,
} from '@/components/ui/number-field'
</script>
<style>
#dialog-close {
    display: none !important;
}
</style>
<template>
    <Dialog>
        <DialogTrigger as-child>
            <PagesHomePoolButtonSuggestion />
        </DialogTrigger>
        <DialogContent class="h-full w-full">
            <VisuallyHidden>
                <DialogTitle></DialogTitle>
            </VisuallyHidden>
            <DialogDescription>
                <div class="flex flex-col gap-2  w-full h-full items-start relative">
                    <div class="h-20 inline-flex justify-between items-center gap-2">
                        <DialogClose as-child>
                            <button>
                                <ArrowLeft class="size-8 text-gray-700" />
                            </button>
                        </DialogClose>
                        <span class="text-2xl text-gray-700 poppins-regular">Jack Russel</span>
                    </div>
                    <div class="w-full space-y-3">
                        <img src="/mocks/car-1.jpeg" class="rounded-lg" alt="">
                        <div class="w-full inline-flex justify-between items-center">

                            <div class="w-full inline-flex items-center justify-start gap-6 text-gray-700 py-2">
                                <div class="inline-flex flex-nowrap items-center justify-start gap-2">
                                    <Timer clas="size-10" />
                                    <span class="text-xl">2h</span>
                                </div>
                                <div class="inline-flex flex-nowrap items-center justify-start gap-2">
                                    <Star clas="size-10" />
                                    <span class="text-xl">4.5</span>
                                </div>
                                <div class=" inline-flex flex-nowrap items-center justify-start gap-2">
                                    <img src="/vehicles/bicycle.svg" class="size-8" />
                                </div>
                            </div>
                            <div class="text-2xl poppins-bold text-black text-nowrap">
                                10K Ar
                            </div>
                        </div>
                    </div>
                    <div class="h-60 w-full">
                        <CommonChartBar />
                    </div>
                    <!-- <ScrollArea class=" h-60 w-full overflow-y-hidden">
                    <div class="poppins-regular text-md ">
                        Partez en toute sérénité avec ce trajet de [Ville de départ] à [Ville d’arrivée]. Départ prévu à
                        [Heure], avec des arrêts possibles à [Villes intermédiaires]. Véhicule confortable, bonne
                        ambiance assurée et possibilité d’échanger ou de profiter du voyage en toute tranquillité. 🚗💨
                        ambiance assurée et possibilité d’échanger ou de profiter du voyage en 
                        ambiance assurée et possibilité d’échanger ou de profiter du voyage en 
                        ambiance assurée et possibilité d’échanger ou de profiter du voyage en 
                        ambiance assurée et possibilité d’échanger ou de profiter du voyage en 
                        ambiance assurée et possibilité d’échanger ou de profiter du voyage en 
                        ambiance assurée et possibilité d’échanger ou de profiter du voyage en 
                    </div>
                </ScrollArea> -->
                    <div class="w-full absolute bottom-0 left-0">
                        <NumberField class="w-full" id="age" :default-value="1" :min="1" :max="4">
                        <Label for="age" class="text-xl poppins-bold">3 places dispo</Label>
                        
                        
                        
                        <div class="w-full inline-flex justify-between gap-2">
                            <div class="w-full">
                                <NumberFieldContent>
                                <NumberFieldDecrement />
                                <NumberFieldInput  class="poppins-regular bg-gray-200 rounded-none text-gray-700 text-2xl" />
                                <NumberFieldIncrement />
                            </NumberFieldContent>
                            </div>
                            <button class="bg-yellow-500 text-gray-700 w-full h-full poppins-regular text-2xl">
                                    reserver
                            </button>
                        </div>
                        
                       
                    </NumberField>
                    
                    </div>
                </div>
            </DialogDescription>
        </DialogContent>
    </Dialog>
</template>