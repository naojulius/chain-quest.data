
<template>
    <component :is="usePageStore().getPage.component"  class="animate-fade animate-once"/>
</template>
