<template>
  <NuxtLayout>
    <NuxtPage />
  </NuxtLayout>
  <CommonLoaderMain />
  <Toaster />
</template>
<script lang="ts" setup>
  import { Toaster } from '@/components/ui/sonner'
</script>
