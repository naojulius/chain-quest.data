export default defineNuxtRouteMiddleware((to, from) => {
  const router = useRouter()
  let user = useCookie<{ id: number; name: string } | null>('user')
  // user = useCookie<{ id: number; name: string }>('user', { maxAge: 60 * 60 * 24 }) // 1 day
  // user.value = { id: 1, name: 'John Doe' }
  // user.value = null
  if (!user.value && to.path !== '/auth') {
     //navigateTo('/auth', { replace: true })
     router.push({ path: "/auth" })
  }

  if (user.value && to.path !== '/') {
    router.push({ path: "/auth" })
  }
})
