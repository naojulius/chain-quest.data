import{J as u,d as a,t as c,v as r,z as o,L as p,r as d,x as s,M as m,a7 as g,i as x}from"./EVqyM_U4.js";import{_}from"./DlAUqK2U.js";/**
 * @license lucide-vue-next v0.474.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=u("InfoIcon",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]]);/**
 * @license lucide-vue-next v0.474.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=u("MessageCircleIcon",[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z",key:"vv11sd"}]]);/**
 * @license lucide-vue-next v0.474.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=u("PhoneIcon",[["path",{d:"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z",key:"foiqr5"}]]),P={class:"size-12 p-2 rounded-full text-gray-700 bg-gray-200"},$=a({__name:"Phone",setup(t){return(e,n)=>(c(),r("button",P,[o(p(v),{class:"size-full"})]))}}),b={class:"size-12 p-2 rounded-full text-gray-700 bg-gray-200"},M=a({__name:"Message",setup(t){return(e,n)=>(c(),r("button",b,[o(p(y),{class:"size-full"})]))}}),z={class:"size-12 p-2 rounded-full text-gray-700 bg-gray-200"},k=a({__name:"Info",setup(t){return(e,n)=>(c(),r("button",z,[o(p(h),{class:"size-full"})]))}}),C={class:"flex flex-col gap-4"},I={class:"bg-yellow-500 h-auto w-full rounded-2xl p-2"},w={class:"inline-flex items-center justify-between w-full"},B={class:"inline-flex items-center justify-end gap-2 w-full py-2"},S=a({__name:"index",setup(t){return d([]),(e,n)=>{const i=$,l=M,f=k;return c(),r("div",C,[s("div",I,[n[1]||(n[1]=s("div",null,[s("div",{class:"text-lg text-gray-700 poppins-regular"},"Départ imminent, restez attentif !"),s("div",{class:"text-3xl font-bold text-gray-700 py-4 poppins-bold"},"Co-Voiturage avec Randria et 2 autres personnes")],-1)),s("div",w,[n[0]||(n[0]=s("div",{class:"w-full text-xl font-bold text-gray-700 poppins-medium"}," dans 30 mn ",-1)),s("div",B,[o(i),o(l),o(f)])])])])}}}),L={};function A(t,e){const n=S;return c(),m(n)}const V=_(L,[["render",A]]),j={};function H(t,e){return" Map Page "}const N=_(j,[["render",H]]),q={};function D(t,e){return" Search Page "}const E=_(q,[["render",D]]),J={};function R(t,e){return" Settings Page "}const Z=_(J,[["render",R]]),K=g("page",()=>{let t=d("home");const e=[{component:V},{component:N},{component:E},{component:Z}],n=function(l){t.value=l},i=x(()=>{switch(t.value){case"home":return e[0];case"search":return e[1];case"map":return e[2];case"setting":return e[3];default:return e[0]}});return{page:t,setPage:n,getPage:i}});export{K as u};
