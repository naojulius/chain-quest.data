import{_ as t}from"./DlAUqK2U.js";import{_ as e}from"./EVqyM_U4.js";const o={};function s(r,n){return e(r.$slots,"default")}const c=t(o,[["render",s]]);export{c as default};
