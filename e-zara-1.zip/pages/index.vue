
<template>
    <component :is="usePageStore().getPage.component"  class="animate-fade animate-once"/>
</template>
<script lang="ts" setup>

</script>
