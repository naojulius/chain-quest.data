<script lang="ts" setup>
definePageMeta({
    layout: 'auth'
});
import { useAuthStore } from "~/stores/auth.store";
const authStore = useAuthStore();
</script>
<template>
    <!-- <PagesAuth /> -->
    <component :is="authStore.getPage.component"/>
</template>