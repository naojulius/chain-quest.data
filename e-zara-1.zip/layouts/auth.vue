<template>
    <slot />
</template>