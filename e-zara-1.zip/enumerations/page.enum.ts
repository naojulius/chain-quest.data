export enum PAGE_ENUM {
    HOME, SEARCH, MAP, SETTING
}