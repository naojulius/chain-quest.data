export const BottomNavigationButtons = [
    {
        id: 0,
        name: "home",
        href: "",
        icon: "Home",
        active: true
    },
    {
        id: 1,
        name: "search",
        href: "",
        icon: "Search",
        active: false
    },
    {
        id: 2,
        name: "map",
        href: "",
        icon: "Map",
        active: false
    },
    {
        id: 3,
        name: "setting",
        href: "",
        icon: "Cog",
        active: false
    }
]