import { 
    PagesAuth, 
    PagesAuthLogin, 
    PagesAuthRegister, 
    PagesAuthRegistrationStepEmail, 
    PagesAuthRegistrationStepPassword,
    PagesAuthRegistrationStepPin,
    PagesAuthRegistrationStepProfile,    
} from "#components";
import { type ComponentOptionsMixin, type DefineComponent, type PublicProps } from 'vue';
export const useAuthStore = defineStore('auth', () => {
    interface IPage {
        component: DefineComponent<{}, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {} >,
    }

    let isAuthenticated = ref(false);
    let page = ref("index")
    let registerPage = ref("email")
    let registerParentPageData = ref(
        {
            title: "Nouveau!",
            text: "Rejoignez E-Zara, la solution de covoiturage malgache qui connecte les voyageurs."
        }
    )

    let passwordButtonEyeclosed = ref(false)
    const pages: Array<IPage> = [
        {component: PagesAuth},
        {component: PagesAuthLogin},
        {component: PagesAuthRegister},
    ]

    const pagesRegister: Array<IPage> = [
        {component: PagesAuthRegistrationStepEmail},
        {component: PagesAuthRegistrationStepPassword},
        {component: PagesAuthRegistrationStepPin},
        {component: PagesAuthRegistrationStepProfile},
    ]

    const togglePasswordButtonEye = function (){
        passwordButtonEyeclosed.value = !passwordButtonEyeclosed.value;
    }

    const setPasswordButtonEyeclosed = function(state: boolean){
        passwordButtonEyeclosed.value = state;
    }

    const setPage = function (name: string) {
        page.value = name;
    }

    const setRegisterPage =  function (name: string){
        registerPage.value = name;
    }
    const getPage = computed(()=>{
        switch (page.value) {
            case "index":
                return pages[0];
            case "login":
                return pages[1];
            case "register":
                return pages[2];
            default:
                return pages[0];
        }
        
    });
    const getRegisterPage = computed(()=>{
        switch (registerPage.value) {
            case "email":
                registerParentPageData.value =
                    {
                        title: "Nouveau!",
                        text: "Rejoignez E-Zara, la solution de covoiturage malgache qui connecte les voyageurs."
                    }
                return pagesRegister[0];
            case "password":
                registerParentPageData.value =
                {
                    title: "Mots de passe,",
                    text: "Creer votre mots de passe pour une connexion securise."
                }
                return pagesRegister[1];
            case "pin":
                registerParentPageData.value =
                {
                    title: "Pin",
                    text: "Nous vous avons envoyer un code pin de 4 chiffre a ****@gmail.com. Verifions qu'il s'agit bien de vous."
                }
                return pagesRegister[2];
            case "profile":
                registerParentPageData.value =
                {
                    title: "Profile",
                    text: "Nous vous avons envoyer un code pin de 4 chiffre a ****@gmail.com. Verifions qu'il s'agit bien de vous."
                }
                return pagesRegister[3];
                
            default:
                return pagesRegister[0];
        }
        
    });
    const checkPassWord = (data: any) =>{
        if(data.password.lenght <= 8){
            return {
                valid: false, 
                title: "Erreur",
                text: "Mots de passe trop court!"
            }
        }

        if(data.password != data.passwordConfirm){
            return {
                valid: false, 
                title: "Erreur",
                text: "Mots de non identique!"
            }
        }
        return {
            valid: true,
            title: '',
            text: '',
        }
    }
    const checkEmail = (email: string): boolean =>{
        return  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }
    return {
        setPage, 
        getPage, 
        setRegisterPage, 
        getRegisterPage, 
        registerParentPageData,
        togglePasswordButtonEye, 
        passwordButtonEyeclosed, 
        setPasswordButtonEyeclosed,
        checkPassWord,
        checkEmail, 
        isAuthenticated
    }
});