import { PagesHome, PagesMap, PagesSearch, PagesSetting } from "#components";
import type { ShallowRefMarker } from "@vue/reactivity";
import { shallowRef, type ComponentOptionsMixin, type DefineComponent, type PublicProps } from 'vue';
export const usePageStore = defineStore('page', () => {
    interface IPage {
        component: DefineComponent<{}, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {} >,
    }

    let page = ref("home");

    const pages: Array<IPage> = [
        {component: PagesHome},
        {component: PagesMap},
        {component: PagesSearch},
        {component: PagesSetting},
    ]


    const setPage = function (name: string) {
        page.value = name;
    }

    const getPage = computed(()=>{
        switch (page.value) {
            case "home":
                return pages[0];
            case "search":
                return pages[1];
            case "map":
                return pages[2];
            case "setting":
                return pages[3];
            default:
                return pages[0];
        }
        
    });
    return {
        page, setPage, getPage
    }
});