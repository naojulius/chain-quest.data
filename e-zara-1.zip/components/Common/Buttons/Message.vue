<script lang="ts" setup>
import { MessageCircle} from 'lucide-vue-next';
</script>
<template>
    <button class="size-12 p-2 rounded-full text-gray-700 bg-gray-200">
        <MessageCircle  class="size-full"/>
    </button>
</template>