<script lang="ts" setup>
import { Eye, EyeClosed} from 'lucide-vue-next'
const isClosed = ref(useAuthStore().passwordButtonEyeclosed);
</script>
<template>
    <button @click="useAuthStore().togglePasswordButtonEye" type="button" class="size-12 p-2 rounded-full text-gray-700 bg-yellow-500">
        <EyeClosed v-if="useAuthStore().passwordButtonEyeclosed"  class="size-full text-gray-600"/>
        <Eye v-if="!useAuthStore().passwordButtonEyeclosed"  class="size-full text-gray-600"/>
    </button>
</template>