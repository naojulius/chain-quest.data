<script lang="ts" setup>
import { LoaderCircle } from 'lucide-vue-next';
</script>
<template>
    <div v-if="useLoaderStore().loading" class="h-screen w-full flex justify-center items-center flex-col gap-2 z-20 absolute top-0 overflow-hidden bg-gray-500 bg-opacity-50"></div>
    <transition  enter-active-class="animate-jump animate-once animate-duration-200" leave-active-class="animate-jump-out animate-once animate-duration-200">
        <div v-if="useLoaderStore().loading" class="h-screen w-full flex justify-center items-center flex-col gap-2 z-50 absolute top-0 overflow-hidden transparent">
            <div class="flex justify-center items-center flex-col gap-2 bg-white p-6 shadow-lg rounded-xl" v-if="useLoaderStore().loading">
            <LoaderCircle class="size-12 text-gray-700 animate-spin" />
            <span class="text-lg text-gray-700 poppins-medium">
                Veuillez patienter!
            </span>
        </div>
        </div>
        
    </transition>
</template>