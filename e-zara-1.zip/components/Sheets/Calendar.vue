<script setup lang="ts">
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
</script>

<template>
  <Dialog>
    <DialogTrigger as-child>
      <!-- <Button variant="outline">
        Edit Profile
      </Button> -->
      <CommonButtonsCalendar/>
    </DialogTrigger>
    <DialogContent class="h-full">
      <DialogHeader>
        <DialogTitle>Mes Calendrier</DialogTitle>
      </DialogHeader>
     <div class="size-full">
        
     </div>
      <!-- <DialogFooter>
        <Button type="submit">
          Save changes
        </Button>
      </DialogFooter> -->
    </DialogContent>
  </Dialog>
</template>