<script setup lang="ts">
import { Cog } from 'lucide-vue-next';
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
</script>

<template>
  <Sheet>
    <SheetTrigger as-child>
      <CommonButtonsBell/>
    </SheetTrigger>
    <SheetContent>
      <SheetHeader>
        <SheetTitle>Notifications</SheetTitle>
      </SheetHeader>
      <div class="flex flex-col gap-2  w-full h-full ">
                <div class=" flex-col overflow-hidden p-1 border-b-2 bg-gray-100">
                    <div class="inline-flex items-center justify-between w-full">
                        <div class="inline-flex items-center gap-2">
                            <Cog class="size-4" />
                            <span>System</span>
                        </div>
                        <span>
                            10h:20
                        </span>
                    </div>
                    <div class="text-sm">Une connexion non identifie a ete detecte pres de nanisana</div>
                </div>
                <div class="flex-col overflow-hidden p-1 border-b-2 bg-gray-100">
                    <div class="inline-flex items-center justify-between w-full">
                        <div class="inline-flex items-center gap-2">
                            <Cog class="size-4" />
                            <span>System</span>
                        </div>
                        <span>
                            10h:20
                        </span>
                    </div>
                    <div class="text-sm">Une connexion non identifie a ete detecte pres de nanisana</div>
                </div>
      </div>
      
    </SheetContent>
  </Sheet>
</template>