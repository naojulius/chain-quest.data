<script lang="ts" setup>
import { Home, Search, Map, Cog } from 'lucide-vue-next';
import { BottomNavigationButtons } from '~/constants/bottom.nav';
import { usePageStore } from "~/stores/page.store";
const pageStore = usePageStore();
const icons = { Home, Search, Map, Cog} as any;
const navigaitonButtons = ref(BottomNavigationButtons)
const onClickNavButton = (btn: any) =>{
    navigaitonButtons.value.forEach((item:any) => {
        item.active = false;
        if (item.id == btn.id) {
            item.active = true;
            pageStore.setPage(btn.name)
        }
    });
}
</script>
<template>
    <div class="h-20 w-full p-2 fixed bottom-0">
        <div class="size-full bg-yellow-500 rounded-2xl inline-flex justify-between items-center px-1">
            <button @click="onClickNavButton(nav)"  v-for="(nav, index) in navigaitonButtons" :key="index" class="size-14 rounded-full relative flex items-center justify-center">
                <component :is="icons[nav.icon]" class="text-gray-700 size-full p-2" />
                <div v-if="nav.active" class="h-[5px] w-[35px] bg-gray-700 absolute bottom-[2px] rounded-full animate-pulse animate-once"></div>
            </button>
        </div>
    </div>
</template>