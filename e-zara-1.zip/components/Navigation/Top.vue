<template>
    <div class="h-20 w-full p-4 fixed top-0 z-5 bg-white">
        <div class="h-full w-full inline-flex justify-between items-center">
           <div class="inline-flex items-center justify-start h-full">
            <CommonButtonsBlocks />
            <span class="text-2xl font-bold text-gray-600 poppins-bold">E-Zara</span>
           </div>
           <div class="inline-flex items-center justify-end gap-1">
            <!-- <CommonButtonsCalendar /> -->
            <SheetsCalendar/>
             <SheetsNotification />
           </div>
        </div>
    </div>
</template>