<template>
   <PagesHomeCarPool/>
</template>
<script setup lang="ts">
</script>