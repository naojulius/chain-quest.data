<script lang="ts" setup>
import { TEXT } from '~/constants/text';
const onNavigate = (page: string) =>{
    useAuthStore().setPage(page);
}
</script>
<style>
</style>
<template>
    <div class="h-screen flex flex-col justify-start animate-fade-up animate-once animate-duration-75">
      <div class="h-3/5 w-full flex flex-col items-center justify-center">
         <img src="/images/car.svg" class="size-28">
        <div class="text-4xl poppins-bold text-gray-700">
         {{ TEXT.app_name }}
        </div>
        <div class="text-lg poppins-regular">
          Roulez Ensemble
        </div>
      </div>
      <div class="h-2/5 rounded-t-[15%] w-full bg-yellow-500 p-6">
        <div class=" flex flex-col gap-2">
          <span class="text-4xl poppins-bold text-gray-700">
          Bonjour, 
        </span>
        <span class="text-xl poppins-regular text-gray-700 py-4">
          Prêt à rouler ensemble ? Connectez-vous ou inscrivez-vous ! 
        </span>
        <div class="inline-flex gap-2 w-full items-center justify-center">
            <button @click="onNavigate('login')" class="w-1/2 bg-gray-700 text-white h-14 rounded-full poppins-medium">
              Connexion
            </button>
            <button @click="onNavigate('register')" class="w-1/2 bg-white text-gray-700 h-14 rounded-full poppins-medium">
              Inscription
            </button>
        </div>
        </div>
      </div>
    </div>
</template>