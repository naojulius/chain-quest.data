<template>
    <form class="w-full space-y-4 relative h-full"  @submit="onSubmit">
            <FormField v-slot="{ componentField }" name="password">
            <FormItem>
                <FormControl>
                    <CommonInputsPassword v-bind="componentField"  text="Mot de passe"/>
                </FormControl>
            </FormItem>
            </FormField>
            <FormField v-slot="{ componentField }" name="passwordConfirm">
            <FormItem>
                <FormControl class="relative">
                <CommonInputsPassword v-bind="componentField"  text="Confirmer votre mot de passe" />
            </FormControl>
            </FormItem>
            </FormField>
            <button type="submit" class="w-full bg-gray-700 text-white h-14 rounded-full poppins-medium absolute bottom-0">
              Continuer
            </button>
        </form>
</template>
<script lang="ts" setup>
import { toTypedSchema } from '@vee-validate/zod';
import { useForm } from 'vee-validate';
import { toast } from 'vue-sonner';
import * as z  from 'zod';


    useLoaderStore().hide();
    const formSchema = toTypedSchema(z.object({
        password: z.string().min(8).max(50),
        passwordConfirm: z.string().min(8).max(50),
    }));

    const { handleSubmit } = useForm({
        validationSchema: formSchema,
    })
    const onSubmit = handleSubmit((values) => {
    var checkPassWordResp = useAuthStore().checkPassWord(values);
    if(!checkPassWordResp){
        return;
    }

    if (checkPassWordResp && !checkPassWordResp.valid){
        toast(checkPassWordResp.title, {
            description: checkPassWordResp.text,
            class: "text-lg"
        })
        return;
    }

    if (checkPassWordResp && checkPassWordResp.valid){
        useLoaderStore().show();
        setTimeout(() => {
            useAuthStore().setRegisterPage('pin');
        }, 2000);
    }
})
</script>