<script lang="ts" setup>


import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

</script>

<template>
  <Select>
    <SelectTrigger class="h-14 bg-gray-200 w-full rounded-full px-4 text-lg poppins-medium">
      <SelectValue placeholder="Choisissez votre sexe" />
    </SelectTrigger>
    <SelectContent>
      <SelectGroup>
        <SelectLabel></SelectLabel>
        <SelectItem value="male">
         Homme
        </SelectItem>
        <SelectItem value="female">
          Femme
        </SelectItem>
        <SelectItem value="other">
          Autre
        </SelectItem>
      </SelectGroup>
    </SelectContent>
  </Select>
</template>