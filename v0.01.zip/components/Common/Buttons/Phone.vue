<script lang="ts" setup>
import { Phone} from 'lucide-vue-next';
</script>
<template>
    <button class="size-12 p-2 rounded-full text-gray-700 bg-gray-200">
        <Phone  class="size-full"/>
    </button>
</template>