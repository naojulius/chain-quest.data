<script lang="ts" setup>
import { Menu} from 'lucide-vue-next';
</script>
<template>
    <button class="size-12 p-2 rounded-full text-gray-700">
        <Menu  class="size-full"/>
    </button>
</template>