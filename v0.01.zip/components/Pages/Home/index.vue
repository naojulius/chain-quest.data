<template>
   <!-- <div class="w-full">
      <div class="size-full">
         <button
            class="h-14 w-full bg-gray-200 poppins-regular text-lg text-gray-400 px-1 inline-flex items-center justify-center gap-2">
            <Search class="size-8" />
            <span>
               Cherchez des conducteurs
            </span>
         </button>
      </div>
      <ScrollArea class="w-full py-3 overflow-x-scroll py-3">
         <div class="inline-flex items-center gap-x-2 whitespace-nowrap">
            <button v-for="sub in submenus" :key="sub.id"
               :class="['p-1 px-2 inline-flex gap-2 items-center justify-center flex-nowrap text-xl poppins-regular', sub.active ? 'min-w-[105px] bg-yellow-500' : '']">
               <div v-if="sub.active" class="size-8 bg-white flex justify-center items-center">
                  <img src="/vehicles/bicycle.svg" class="size-6">
               </div>
               <span>{{ sub.name }}</span>
            </button>
         </div>
         <ScrollBar orientation="horizontal" />
      </ScrollArea>
      <div class="w-full">
         <div class="text-xl poppins-regular py-4 text-gray-700">
            Suggestion pour vous:
         </div>
         <ScrollArea class="w-full">
            <div class="inline-flex space-x-4 w-max py-2">
              <PagesHomePoolSuggestion v-for="sub in submenus" :key="sub.id" />
            </div>
            <ScrollBar orientation="horizontal" />
         </ScrollArea>
      </div>
   </div> -->
   <PagesHomeCalendar />
</template>
<script setup lang="ts">
import { Search, Timer, Star } from 'lucide-vue-next'
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area'
const route = useRouter()

useLoaderStore().hide();
const submenus = [
   {
      id: '1',
      name: 'Bicyclette',
      image: '/vehicles/bicycle.svg',
      active: true,
   },
   {
      id: '2',
      name: 'Scooter',
      image: '/vehicles/bicycle.svg',
      active: false,
   },
   {
      id: '3',
      name: 'Moto',
      image: '/vehicles/bicycle.svg',
      active: false,
   },
   {
      id: '3',
      name: 'Voiture',
      image: '/vehicles/bicycle.svg',
      active: false,
   },
]

// const onNavigationPooldetail = () => {
//    const id = 1;
//    navigateTo(`/home/pool/${id}`);
// }
</script>