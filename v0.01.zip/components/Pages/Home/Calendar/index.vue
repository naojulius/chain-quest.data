<script setup lang="ts">
import { ref, onMounted } from "vue";
import { RegisteredTracksMock } from "~/public/mocks/tracks/registered.tracks";

// Define types
interface CalendarDay {
    date: number;
    isToday: boolean;
    isCurrentMonth: boolean;
    events: string[]; // Array of event colors
}

// Reactive variables
const currentMonth = ref<number>(new Date().getMonth());
const currentYear = ref<number>(new Date().getFullYear());
const daysInMonth = ref<CalendarDay[]>([]);
const selectedDate = ref<number | null>(null);
const trips = ref<any[]>([]);

// Sample events with different colors (replace with API data if needed)
const events = computed(() => {
    const tripEvents: { [key: number]: string[] } = {};

    RegisteredTracksMock.forEach(trip => {
        const tripDate = new Date(trip.begin_time).getDate(); // Extract day from trip date

        if (!tripEvents[tripDate]) {
            tripEvents[tripDate] = []; // Initialize event array for this day
        }

        if (trip.trip_type === "departure") {
            tripEvents[tripDate].push("bg-green-500"); // Aller
        } else if (trip.trip_type === "return") {
            tripEvents[tripDate].push("bg-red-500"); // Retour
        }
    });

    return tripEvents;
});

// Function to generate the calendar
const generateCalendar = () => {
    const today = new Date();
    const firstDayOfMonth = new Date(currentYear.value, currentMonth.value, 1);
    const lastDayOfMonth = new Date(currentYear.value, currentMonth.value + 1, 0);

    const firstDayWeekday = firstDayOfMonth.getDay(); // Sunday = 0, Monday = 1, etc.
    const totalDays = lastDayOfMonth.getDate();

    daysInMonth.value = [];


    // Add previous month's last few days for alignment
    const prevMonthLastDay = new Date(currentYear.value, currentMonth.value, 0).getDate();
    for (let i = firstDayWeekday - 1; i >= 0; i--) {
        daysInMonth.value.push({
            date: prevMonthLastDay - i,
            isToday: false,
            isCurrentMonth: false,
            events: []
        });
    }

    // Add current month's days
    for (let day = 1; day <= totalDays; day++) {
        daysInMonth.value.push({
            date: day,
            isToday: today.getDate() === day && today.getMonth() === currentMonth.value,
            isCurrentMonth: true,
            events: events.value[day] || [] // Get multiple event colors per day
        });
    }

    // Add next month's first few days for alignment
    const remainingDays = 42 - daysInMonth.value.length; // Ensure 6 full rows
    for (let i = 1; i <= remainingDays; i++) {
        daysInMonth.value.push({
            date: i,
            isToday: false,
            isCurrentMonth: false,
            events: []
        });
    }
};
const handleDateClick = (day: CalendarDay) => {
    selectedDate.value = day.date;
    getTrips(day.date);
    console.log(`📅 Selected Date: ${currentYear.value}-${currentMonth.value + 1}-${day.date}`);
}

// const getTrips = (date: number) =>{
//     var trip = RegisteredTracksMock.sort(() => Math.random() - 0.5).slice(0, Math.floor(Math.random() * RegisteredTracksMock.length));
//     trips.value = trip;
// }

const getTrips = (day: number) => {
    trips.value = RegisteredTracksMock.filter(trip => {
        return new Date(trip.begin_time).getDate() === day;
    });
};

const getEvents = (day: CalendarDay) => {
    let date = day.date;
}
const formatTime = (isoString: string): string => isoString.slice(11, 16);
// Generate calendar on mount
onMounted(() => {
    generateCalendar();

    // Fetch trips for a default day (e.g., today)
    const today = new Date().getDate();
    getTrips(today);
});

</script>

<template>
    
    <div class="h-[calc(100vh-5rem)] w-full inline-flex flex-col ">
        <div class="w-full p-1">
        <div class="grid grid-cols-7 text-center text-gray-600 mb-2 font-poppins-regular">
            <span v-for="day in ['M', 'T', 'W', 'T', 'F', 'S', 'S']" :key="day">
                {{ day }}
            </span>
        </div>
        <div class="grid grid-cols-7 gap-1 text-center">
            <div v-for="(day, index) in daysInMonth" :key="index"
                class="relative flex flex-col items-center justify-center p-2 text-lg font-poppins-regular w-12 h-12 aspect-square"
                :class="[
                    day.isToday
                        ? 'bg-yellow-500 text-white font-poppins-bold rounded-full'
                        : day.isCurrentMonth && selectedDate === day.date
                            ? 'bg-yellow-300 text-gray-700 font-poppins-bold rounded-full'
                            : day.isCurrentMonth
                                ? 'text-gray-900 hover:bg-gray-200 rounded-full'
                                : 'text-gray-400 opacity-50 cursor-default'
                ]" @click="handleDateClick(day)">
                {{ day.date }}

                <div class="flex gap-1 mt-1">
                    <div v-for="(eventColor, i) in day.events" :key="i" class="size-[8px] rounded-full"
                        :class="eventColor">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-white border-t-2 border-gray-300 h-full">
        <ScrollArea class="size-full" v-if="trips.length > 0">
            <div class="inline-flex flex-col border-gray-300 w-full gap-2 p-2">
                <SheetsCalendar v-for="(trip, index) in trips" :key="index" :trip="trip" />
            </div>
        </ScrollArea>
        <div v-if="trips.length <= 0"
            class="size-full bg-gray-200 flex items-center justify-center poppins-regular text-gray-700 text-2xl text-center">
            <div class="">
                <div>
                    Vous n'avez pas de trajets pour ce jour.
                </div>
                <div class="p-4">
                    <button class="bg-yellow-500 p-2 w-full rounded-lg">
                    Creer une?
                </button>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!--  -->
</template>
