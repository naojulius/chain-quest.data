<template>
    <ScrollArea class="h-full mt-60 w-full">
       qasdad
    </ScrollArea>
  </template>
  <script setup lang="ts">
  import { ref } from "vue";
  import { Map, Timer, Star } from 'lucide-vue-next'
  import { RegisteredTracksMock } from "~/public/mocks/tracks/registered.tracks";
  import { useRoute } from "vue-router"
import { ScrollArea } from '@/components/ui/scroll-area'

  
const route = useRoute();
let t = RegisteredTracksMock.find(t => t.id === Number(1));
  const trip = ref(t as any);
  
  // Format Date (17 Janv - 18 Janv)
  const getFormattedTripDate = (begin: string, end: string) => {
    const options: Intl.DateTimeFormatOptions = { day: "numeric", month: "short" };
    const startDate = new Date(begin).toLocaleDateString("fr-FR", options).replace(".", "");
    const endDate = new Date(end).toLocaleDateString("fr-FR", options).replace(".", "");
    return startDate === endDate ? startDate : `${startDate} - ${endDate}`;
  };
  
  // Format Time (HH:mm)
  const formatTime = (time: string) => new Date(time).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  
  </script>
  