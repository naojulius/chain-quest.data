<template>
    <form class="w-full space-y-4 relative h-full"  @submit="onSubmit">
            <FormField v-slot="{ componentField }" name="phoneNumber">
            <FormItem>
                <FormControl>
                    <CommonInputsPhoneNumber v-bind="componentField"  placeholder="3x xx xxx xx"/>
                </FormControl>
            </FormItem>
            </FormField>
            <button type="submit" class="w-full bg-gray-700 text-white h-14 rounded-full poppins-medium absolute bottom-0">
              Continuer
            </button>
        </form>
</template>
<script lang="ts" setup>
import { toTypedSchema } from '@vee-validate/zod';
import { useForm } from 'vee-validate';
import { toast } from 'vue-sonner';
import * as z  from 'zod';


    useLoaderStore().hide();
    const formSchema = toTypedSchema(z.object({
        phoneNumber: z.string()
                        .regex(/^\d{2} \d{2} \d{3} \d{2}$/, "Format invalide : XX XX XXX XX") // Ensure correct mask format
    }));

    const { handleSubmit } = useForm({
        validationSchema: formSchema,
    })
    const onSubmit = handleSubmit((values) => {
        useLoaderStore().show();
        const phone: string = `+261${values.phoneNumber.replace(/\s/g, "")}`;
        setTimeout(() => {
            useAuthStore().setRegisterPage('legalnotice');
        }, 2000);
    
})
</script>