<script setup lang="ts">
import { TEXT } from '~/constants/text';
</script>

<template>
    <div class="h-20 w-full p-4 fixed top-0 z-5 bg-white">
        <div class="h-full w-full inline-flex justify-between items-center">
           <!-- <div class="inline-flex items-center justify-start h-full">
            <CommonButtonsMenus />
           </div> -->
           <div class="text-3xl font-bold text-gray-600 poppins-bold">
            {{ TEXT.app_name }}</div>
           <div class="inline-flex items-center justify-end gap-1">
            <SheetsAddPool />
            <SheetsNotification />
           </div>
        </div>
    </div>
</template>