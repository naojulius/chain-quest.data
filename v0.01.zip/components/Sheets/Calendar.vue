<script setup lang="ts">
const props = defineProps({
  trip: {
    required: true,
    type: Object,
    default: () => ({})
  },
})
const formatTime = (isoString: string): string => isoString.slice(11, 16);
const getFormattedTripDate = (begin_time: string, end_time: string): string => {
  const options: Intl.DateTimeFormatOptions = { day: "numeric", month: "short" };

  const startDate = new Date(begin_time);
  const endDate = new Date(end_time);

  const startFormatted = startDate.toLocaleDateString("fr-FR", options).replace(".", ""); // "17 janv"
  const endFormatted = endDate.toLocaleDateString("fr-FR", options).replace(".", ""); // "18 janv"

  return startFormatted === endFormatted ? startFormatted : `${startFormatted} - ${endFormatted}`;
};

import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area'
import { VisuallyHidden } from 'radix-vue'
import { ArrowLeft, ArrowRight, ChevronLeft, ChevronRight, CalendarX2, User, Clock, Map, MapPinIcon } from 'lucide-vue-next'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'

import {
  Dialog,
  DialogContent,
  DialogTrigger,
  DialogDescription,
  DialogTitle,
} from '@/components/ui/dialog'
</script>
<style>
#dialog-close {
  display: none !important;
}
</style>
<template>
  <Dialog>
    <DialogTrigger as-child>
      <div
        :class="['w-full flex flex-row gap-4 rounded-lg p-2 items-start shadow', props.trip.trip_type == 'return' ? 'bg-red-100' : 'bg-green-100']">
        <div
          :class="['size-4 min-w-4 min-h-4 rounded-full mt-1', props.trip.trip_type == 'return' ? 'bg-red-600' : 'bg-green-600']">
        </div>
        <div class="h-full w-full inline-flex flex-col relative">
          <span class="text-2xl poppins-bold text-gray-700">
            {{ props.trip.start_point.city }} -> {{ props.trip.end_point.city }}
          </span>
          <span class="text-xl poppins-regular text-gray-500">
            {{ formatTime(props.trip.begin_time) }} -> {{ formatTime(props.trip.end_time) }}
          </span>
          <div class="py-2 text-lg text-gray-500 poppins-regular">
            {{ trip.description }}
          </div>
        </div>
      </div>
    </DialogTrigger>
    <DialogContent class="h-full w-full">
      <VisuallyHidden>
        <DialogTitle></DialogTitle>
      </VisuallyHidden>
      <DialogDescription>
        <div class="absolute top-0 left-0 w-full  h-full overflow-hidden rounded-t-lg">
          <img src="/mocks/car-1.jpeg">

        </div>
        <div class="bg-white w-full h-[calc(100vh-13.3rem)] rounded-t-lg absolute top-52 left-0 p-2">
          <div class="text-2xl px-3 poppins-bold text-gray-700 inline-flex flex-col gap-0">
            <span>{{ props.trip.start_point.city }} -> {{ props.trip.end_point.city }}</span>
            <span class="text-sm poppins-regular text-gray-500">Avec Arthur LKerbi</span>
          </div>
          <div class="py-5">
            <div class="h-full w-full bg-gray-100 p-2 rounded-lg inline-flex gap-2 items-center ">
              <Clock class="size-10 min-w-10 text-white bg-gray-500 rounded-full p-1" />
              <div class="inline-flex flex-col w-full">
                <span class="text-lg poppins-regular font-bold text-gray-800"> {{ formatTime(props.trip.begin_time) }}
                  -> {{ formatTime(props.trip.end_time) }}</span>
                <div class="inline-flex w-full items-center justify-between">
                  <div class="w-full h-full">
                    ⭐ <b>5.0</b> <span> ● 14 revue</span>
                  </div>
                  <div class="inline-flex w-full h-full items-end justify-end poppins-regular text-xs text-gray-800">
                    voir sur map >
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="p-2 w-full h-full">
            <span class="text-gray-900 poppins-regular">Co-Voitureurs</span>
            <ScrollArea class="h-28 w-max py-2">
              <div class="inline-flex gap-2">
                <Avatar class="size-16">
                  <AvatarImage src="https://github.com/radix-vue.png" />
                  <AvatarFallback>CN</AvatarFallback>
                </Avatar>

                <Avatar class="size-16">
                  <AvatarImage src="https://github.com/radix-vue.png" />
                  <AvatarFallback>CN</AvatarFallback>
                </Avatar>

                <Avatar class="size-16">
                  <AvatarImage src="https://github.com/radix-vue.png" />
                  <AvatarFallback>CN</AvatarFallback>
                </Avatar>

                <Avatar class="size-16">
                  <AvatarImage src="https://github.com/radix-vue.png" />
                  <AvatarFallback>CN</AvatarFallback>
                </Avatar>
              </div>
              <!-- <div class="h-full w-max inline-flex gap-3">
                  <div class="w-[150px] h-[70px] bg-white rounded-xl border-[1px] border-gray-200 p-2 px-3 inline-flex flex-col ">
                      <span class="text-smpoppins-regular">Engine</span>
                      <span class="text-md poppins-regular">2Littre/ 100km</span>
                  </div>
                  <div class="w-[150px] h-[70px] bg-white rounded-xl border-[1px] border-gray-200 p-2 px-3 inline-flex flex-col ">
                      <span class="text-smpoppins-regular">Engine</span>
                      <span class="text-md poppins-regular">2Littre/ 100km</span>
                  </div>
                  <div class="w-[150px] h-[70px] bg-white rounded-xl border-[1px] border-gray-200 p-2 px-3 inline-flex flex-col ">
                      <span class="text-smpoppins-regular">Engine</span>
                      <span class="text-md poppins-regular">2Littre/ 100km</span>
                  </div>
                  <div class="w-[150px] h-[70px] bg-white rounded-xl border-[1px] border-gray-200 p-2 px-3 inline-flex flex-col ">
                      <span class="text-smpoppins-regular">Engine</span>
                      <span class="text-md poppins-regular">2Littre/ 100km</span>
                  </div>
              </div> -->
            </ScrollArea>
          </div>
          <div class="">

          </div>
        </div>
      </DialogDescription>
    </DialogContent>
  </Dialog>
</template>