<script setup lang="ts">
import { VisuallyHidden } from 'radix-vue'
import { ArrowLeft, Cog , BellRing} from 'lucide-vue-next'
import {
  Dialog,
  DialogContent,
  DialogTrigger,
  DialogDescription,
  DialogTitle,
} from '@/components/ui/dialog'
</script>
<style>
  #dialog-close{
    display: none !important;
  }
</style>
<template>
  <Dialog>
    <DialogTrigger as-child>
      <CommonButtonsAdd />
    </DialogTrigger>
    <DialogContent class="h-full w-full">
      <VisuallyHidden>
        <DialogTitle></DialogTitle>
      </VisuallyHidden>
      <DialogDescription>
      <div class="flex flex-col gap-2  w-full h-full items-start">
        <div class="h-20 inline-flex justify-between items-center gap-2">
          <DialogClose as-child>
            <button>
                <ArrowLeft  class="size-8 text-gray-700"/>
            </button>
          </DialogClose>
        </div>
        <div class="w-full text-center text-2xl poppins-bold text-gray-700">
            Ajouter votre propre destination
        </div>
        <div class="h-full w-full flex flex-col gap-2 items-center justify-center absolute left-0 bg-yellow-500 mt-48 rounded-t-xl">
            
        </div>
      </div>
    </DialogDescription>
    </DialogContent>
  </Dialog>
</template>