<script setup lang="ts">
import { ScrollArea, ScrollBar  } from '@/components/ui/scroll-area'
import { VisuallyHidden } from 'radix-vue'
import { ArrowLeft, ArrowRight, ChevronLeft, ChevronRight, CalendarX2, Star} from 'lucide-vue-next'
import {
  Dialog,
  DialogContent,
  DialogTrigger,
  DialogDescription,
  DialogTitle,
} from '@/components/ui/dialog'
const setTab = (tabName: string)=>{
  useProfileTabStore().setPage(tabName);
} 
const logout = () =>{
  useAuthStore().logout();
}
</script>
<style>
  #dialog-close{
    display: none !important;
  }
</style>
<template>
  <Dialog>
    <DialogTrigger as-child>
      <CommonButtonsUser />
    </DialogTrigger>
    <DialogContent class="h-full w-full">
      <VisuallyHidden>
        <DialogTitle></DialogTitle>
      </VisuallyHidden>
      <DialogDescription>
      <div class="flex flex-col gap-2  w-full h-full items-start">
        <div class=" inline-flex justify-between items-center gap-2 w-full">
          <div class="inline-flex items-center gap-2 w-3/5">
            <DialogClose as-child>
            <button>
                <ArrowLeft  class="size-8 text-gray-700"/>
            </button>
          </DialogClose>
          </div>
          <!-- <div class="text-right flex items-center  justify-end w-2/5 text-xl poppins-bold text-gray-700">
            <CommonButtonsUser @click="setTab('chart')"/>
            <CommonButtonsWallet @click="setTab('wallet')" />
            <CommonButtonsPreference @click="setTab('preference')" />
        </div> -->
        <CommonButtonsPreference @click="logout()" />
        </div>
        <!-- <ScrollArea class="h-[80vh] w-full"> -->
        <component :is="useProfileTabStore().getPage.component" />  
      <!-- </ScrollArea> -->
      </div>
    </DialogDescription>
    </DialogContent>
  </Dialog>
</template>