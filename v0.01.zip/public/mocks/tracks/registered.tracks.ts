export const RegisteredTracksMock = [
    {
        "id": 1,
        "description": "Trajet matinal vers Paris",
        "driver": {
            "name": "Jean Dupont",
            "rating": 4.8,
            "phone": "+33 6 12 34 56 78",
            "vehicle": {
                "brand": "Peugeot",
                "model": "208",
                "color": "Bleu",
                "license_plate": "AB-123-CD"
            }
        },
        "seats_available": 3,
        "price": 15.50,
        "currency": "EUR",
        "begin_time": "2025-02-05T07:30:00",
        "end_time": "2025-02-05T09:00:00",
        "start_point": {
            "city": "Lyon",
            "address": "Gare Part-Dieu, Lyon",
            "latitude": 45.7640,
            "longitude": 4.8357
        },
        "end_point": {
            "city": "Paris",
            "address": "Gare de Lyon, Paris",
            "latitude": 48.8566,
            "longitude": 2.3522
        },
        "stops": [
            {
                "city": "Dijon",
                "address": "Aire d'autoroute Dijon Sud",
                "latitude": 47.3220,
                "longitude": 5.0415,
                "stop_time": "2025-02-05T08:15:00"
            }
        ],
        "payment_methods": ["Cash", "Card", "PayPal"],
        "duration": "1h 30m",
        "status": "Available", 
        "trip_type": "departure"
    },
    {
        "id": 2,
        "description": "Retour du travail vers Orléans",
        "driver": {
            "name": "Marie Lefevre",
            "rating": 4.9,
            "phone": "+33 6 98 76 54 32",
            "vehicle": {
                "brand": "Renault",
                "model": "Clio",
                "color": "Rouge",
                "license_plate": "CD-456-EF"
            }
        },
        "seats_available": 2,
        "price": 10.00,
        "currency": "EUR",
        "begin_time": "2025-02-05T18:00:00",
        "end_time": "2025-02-05T19:30:00",
        "start_point": {
            "city": "Paris",
            "address": "La Défense",
            "latitude": 48.8924,
            "longitude": 2.2385
        },
        "end_point": {
            "city": "Orléans",
            "address": "Gare d'Orléans",
            "latitude": 47.9029,
            "longitude": 1.9092
        },
        "stops": [],
        "payment_methods": ["Cash", "Lydia"],
        "duration": "1h 30m",
        "status": "Available", 
        "trip_type": "return"
    },
    {
        "id": 3,
        "description": "Déplacement pro vers Marseille",
        "driver": {
            "name": "Alex Martin",
            "rating": 4.7,
            "phone": "+33 7 45 67 89 01",
            "vehicle": {
                "brand": "Tesla",
                "model": "Model 3",
                "color": "Noir",
                "license_plate": "GH-789-IJ"
            }
        },
        "seats_available": 1,
        "price": 25.00,
        "currency": "EUR",
        "begin_time": "2025-02-06T08:00:00",
        "end_time": "2025-02-06T12:30:00",
        "start_point": {
            "city": "Lyon",
            "address": "Aéroport Lyon-Saint Exupéry",
            "latitude": 45.7266,
            "longitude": 5.0904
        },
        "end_point": {
            "city": "Marseille",
            "address": "Vieux Port, Marseille",
            "latitude": 43.2965,
            "longitude": 5.3698
        },
        "stops": [
            {
                "city": "Valence",
                "address": "Aire d'autoroute Valence Nord",
                "latitude": 44.9334,
                "longitude": 4.8924,
                "stop_time": "2025-02-06T09:30:00"
            }
        ],
        "payment_methods": ["PayPal", "Card"],
        "duration": "4h 30m",
        "status": "Available",
        "trip_type": "departure"
    },
    {
        "id": 4,
        "description": "Covoiturage week-end vers Bordeaux",
        "driver": {
            "name": "Emma Moreau",
            "rating": 4.6,
            "phone": "+33 7 11 22 33 44",
            "vehicle": {
                "brand": "Volkswagen",
                "model": "Golf",
                "color": "Gris",
                "license_plate": "KL-012-MN"
            }
        },
        "seats_available": 4,
        "price": 20.00,
        "currency": "EUR",
        "begin_time": "2025-02-09T10:00:00",
        "end_time": "2025-02-09T14:30:00",
        "start_point": {
            "city": "Toulouse",
            "address": "Capitole, Toulouse",
            "latitude": 43.6045,
            "longitude": 1.4442
        },
        "end_point": {
            "city": "Bordeaux",
            "address": "Place des Quinconces, Bordeaux",
            "latitude": 44.8378,
            "longitude": -0.5792
        },
        "stops": [],
        "payment_methods": ["Cash", "Card"],
        "duration": "4h 30m",
        "status": "Available",
        "trip_type": "return"
    },
    {
        "id": 5,
        "description": "Trajet rapide vers Lille",
        "driver": {
            "name": "Luc Bernard",
            "rating": 4.9,
            "phone": "+33 6 33 22 44 55",
            "vehicle": {
                "brand": "BMW",
                "model": "X1",
                "color": "Blanc",
                "license_plate": "OP-345-QR"
            }
        },
        "seats_available": 3,
        "price": 12.00,
        "currency": "EUR",
        "begin_time": "2025-02-10T15:00:00",
        "end_time": "2025-02-10T17:00:00",
        "start_point": {
            "city": "Bruxelles",
            "address": "Gare du Midi, Bruxelles",
            "latitude": 50.8503,
            "longitude": 4.3517
        },
        "end_point": {
            "city": "Lille",
            "address": "Euralille, Lille",
            "latitude": 50.6292,
            "longitude": 3.0573
        },
        "stops": [],
        "payment_methods": ["Cash", "Card", "PayPal"],
        "duration": "2h",
        "status": "Available",
        "trip_type": "departure"
    }
]


