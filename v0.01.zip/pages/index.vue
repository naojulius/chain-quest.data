<template>
    <div class="h-[calc(100vh-4rem)] flex items-center justify-center">
        <span>
            <LoaderCircle class="size-12 text-gray-300 animate-spin" />
        </span>
    </div>
</template>
<script lang="ts" setup>
import { LoaderCircle } from 'lucide-vue-next';
definePageMeta({
    layout: 'skeleton'
});
</script>
