export const TEXT = {
    app_name: "Zara"
}