<template>
    <SkeletonTopNavigation />
    <slot />
    <SkeletonBottomNavigation />
</template>