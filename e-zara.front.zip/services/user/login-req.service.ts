export class LoginReq{
    "email": string;
    "password": string;
}