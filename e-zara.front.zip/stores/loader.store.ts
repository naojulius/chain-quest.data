
export const useLoaderStore = defineStore('loader', () => {

    const loading = ref(false)
    const show = function () {
        loading.value = true;
    }
    const hide = function () {
        loading.value = false;
    }

    
    return {
        loading, show, hide
    }
});