

import { PagesProfileChart, PagesProfilePreference, PagesProfileWallet } from '#components';
import { type ComponentOptionsMixin, type DefineComponent, type PublicProps } from 'vue';
export const useProfileTabStore = defineStore('profileTab', () => {
    interface IPage {
        component: DefineComponent<{}, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly<globalThis.ExtractPropTypes<{}>>, {}, {} >,
    }

    let page = ref("chart");

    const pages: Array<IPage> = [
        {component: PagesProfileChart},
        {component: PagesProfileWallet},
        {component: PagesProfilePreference},
    ]


    const setPage = function (name: string) {
        page.value = name;
    }

    const getPage = computed(()=>{
        switch (page.value) {
            case "chart":
                return pages[0];
            case "wallet":
                return pages[1];
            case "preference":
                return pages[2];
            default:
                return pages[0];
        }
        
    });
    return {
        page, setPage, getPage
    }
});