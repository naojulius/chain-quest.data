<script lang="ts" setup>
import { useAuthStore } from "~/stores/auth.store"
import { ArrowLeft} from 'lucide-vue-next';


const onNavigateBack = (page: string) =>{
    useAuthStore().setPage(page);
}
</script>
<style>
</style>
<template>
    <div class="h-screen flex flex-col justify-start animate-fade-up animate-once animate-duration-75 bg-yellow-500">
      <div class="h-3/6 w-full flex flex-col px-4">
        <div class="h-20 inline-flex justify-between items-center">
            <button @click="onNavigateBack('index')">
                <ArrowLeft  class="size-8 text-gray-700"/>
            </button>
            <button @click="onNavigateBack('login')" class="text-lg poppins-regular text-gray-700 font-bold">
                Connexion
            </button>
        </div>
        <span class="text-3xl poppins-bold text-gray-700">
            {{ useAuthStore().registerParentPageData.title }}
        </span>
        <span class="text-md poppins-regular font-bold text-gray-700 pt-4 pb-2 text-gray-700">
            {{ useAuthStore().registerParentPageData.text }}
        </span>
      </div>
      <div class="h-full rounded-t-[30px] w-full bg-white p-6">
             <component :is="useAuthStore().getRegisterPage.component" />
      </div>
    </div>
</template>