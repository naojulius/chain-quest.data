<script lang="ts" setup>
    import {Settings2Icon} from 'lucide-vue-next';
</script>
<template>
    <button class="size-12 p-2 rounded-full text-gray-700">
        <Settings2Icon  class="size-full"/>
    </button>
</template>