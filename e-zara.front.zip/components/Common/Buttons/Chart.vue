<script lang="ts" setup>
    import { ChartArea} from 'lucide-vue-next';
</script>
<template>
    <button class="size-12 p-2 rounded-full text-gray-700">
        <ChartArea  class="size-full"/>
    </button>
</template>