<script setup lang="ts">
const props = defineProps({
  placeholder: {
    required: true,
    type: String,
  },
})
import { Calendar } from '@/components/ui/calendar'

import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { cn } from '@/lib/utils'
import {
  DateFormatter,
  type DateValue,
  getLocalTimeZone,
} from '@internationalized/date'
import { ref } from 'vue'

const df = new DateFormatter('en-US', {
  dateStyle: 'long',
})

const value = ref<DateValue>()
</script>

<template>
  <Popover>
    <PopoverTrigger as-child>
      <div class="h-14 bg-gray-200 w-full rounded-full text-lg poppins-medium">
        <input readonly  :class="cn(
          'h-14 bg-gray-200 w-full rounded-full text-lg poppins-medium',
          !value && 'text-gray-700',
        )"  autocomplete="off" type="text" :placeholder="props.placeholder" class="h-14 bg-gray-200 w-full rounded-full px-4 text-lg poppins-medium" :value="value ? df.format(value.toDate(getLocalTimeZone())) : ''" />
      </div>
    </PopoverTrigger>
    <PopoverContent class="w-auto p-0">
      <Calendar v-model="value" initial-focus class="text-xl" />
    </PopoverContent>
  </Popover>
</template>