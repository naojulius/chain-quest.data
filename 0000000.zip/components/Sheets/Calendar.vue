<script setup lang="ts">
import { ScrollArea, ScrollBar  } from '@/components/ui/scroll-area'
import { VisuallyHidden } from 'radix-vue'
import { ArrowLeft, ArrowRight, ChevronLeft, ChevronRight, CalendarX2} from 'lucide-vue-next'
import {
  Dialog,
  DialogContent,
  DialogTrigger,
  DialogDescription,
  DialogTitle,
} from '@/components/ui/dialog'
</script>
<style>
  #dialog-close{
    display: none !important;
  }
</style>
<template>
  <Dialog>
    <DialogTrigger as-child>
      <CommonButtonsCalendar />
    </DialogTrigger>
    <DialogContent class="h-full w-full">
      <VisuallyHidden>
        <DialogTitle></DialogTitle>
      </VisuallyHidden>
      <DialogDescription>
      <div class="flex flex-col gap-2  w-full h-full items-start">
        <div class="h-20 inline-flex justify-between items-center gap-2">
          <DialogClose as-child>
            <button>
                <ArrowLeft  class="size-8 text-gray-700"/>
            </button>
          </DialogClose>
          <span class="text-2xl text-gray-700 poppins-regular">Mes Calendriers</span>
        </div>
        <div class="h-full w-full flex flex-col gap-2 items-center justify-center">
          <CalendarX2 class="text-gray-400 size-20"/>  
          <span class="poppins-regular text-xl text-center text-gray-400">
              Votre calendrier est vide pour le moments.
            </span>
        </div>
        <!-- <div class="w-full h-full">
          <div class="h-16 w-full bg-gray-100 inline-flex justify-between items-center px-2">
            <ChevronLeft  class="size-8 text-gray-700"/>
            <span class="text-lg">Ajourdh'ui: 20 Janvier 2024</span>
            <ChevronRight  class="size-8 text-gray-700"/>
          </div>
          <div class="w-full py-2">
            <div class="w-full bg-gray-200 p-2">
              <div class="text-xl poppins-regular">
                à 10h: 30
              </div>
              <div class="py-2 flex flex-col gap-2">
                <div class="flex gap-2 justify-between" >
                      <span class="text-lg poppins-regular">Conducteur :</span> <span class="bg-white text-lg text-gray-700 px-2 rounded-full poppins-regular">Dakoto</span>
                  </div>
                  <div class="flex gap-2 justify-between" >
                      <span class="text-lg poppins-regular">Depart :</span> <span class="bg-white text-lg text-gray-700 px-2 rounded-full poppins-regular">Antanimena</span>
                  </div>
                  <div class="flex gap-2 justify-between">
                      <span class="text-lg poppins-regular">Arrivee :</span> <span class="bg-white text-lg text-gray-700 px-2 rounded-full poppins-regular">Ankorondrano</span>
                  </div>
                  <div class="flex gap-2 justify-between">
                      <span class="text-lg poppins-regular">Estimation :</span> <span class="bg-white text-lg text-gray-700 px-2 rounded-full poppins-regular">2h de route</span>
                </div>
                <div class="flex gap-2 justify-between">
                      <span class="text-lg poppins-regular">Engin :</span> <span class="bg-white text-lg text-gray-700 px-2 rounded-full poppins-regular">Scooter</span>
              </div>
              <div class="flex flex-col gap-2 justify-between">
                      <span class="text-lg poppins-regular">Co-voitureurs :</span> 
                      <ScrollArea  class="h-24 w-[80vw]">
                        <div class="flex flex-row flex-nowrap gap-2">
                          <div class="size-20 min-w-20 bg-white rounded-full"></div>
                          <div class="size-20 min-w-20 bg-white rounded-full"></div>
                        </div>
                         
                        <ScrollBar orientation="horizontal" />
                      </ScrollArea >
              </div>
              </div>
              
              
            </div>
          </div>
        </div> -->
        
      </div>
    </DialogDescription>
    </DialogContent>
  </Dialog>
</template>