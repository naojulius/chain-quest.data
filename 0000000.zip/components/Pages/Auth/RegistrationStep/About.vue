<template>
    <form class="w-full space-y-4 relative h-full"  @submit="onSubmit">
            <FormField v-slot="{ componentField }" name="firstName">
            <FormItem>
                <FormControl>
                    <CommonInputsInput v-bind="componentField"  placeholder="Nom"/>
                </FormControl>
            </FormItem>
            </FormField>
            <FormField v-slot="{ componentField }" name="lastName">
            <FormItem>
                <FormControl>
                    <CommonInputsInput v-bind="componentField"  placeholder="Prénom"/>
                </FormControl>
            </FormItem>
            </FormField>
            <FormField v-slot="{ componentField }" name="birthDate">
            <FormItem>
                <FormControl>
                    <CommonInputsDatePicker v-bind="componentField"  placeholder="Date de naissance"/>
                </FormControl>
            </FormItem>
            </FormField>

            <FormField v-slot="{ componentField }" name="gender">
            <FormItem>
                <FormControl>
                    <CommonInputsSelect v-bind="componentField"  placeholder="Choisissez votre Sexe"/>
                </FormControl>
            </FormItem>
            </FormField>

            <button type="submit" class="w-full bg-gray-700 text-white h-14 rounded-full poppins-medium absolute bottom-0">
              Continuer
            </button>
        </form>
</template>
<script lang="ts" setup>
import { toTypedSchema } from '@vee-validate/zod';
import { useForm } from 'vee-validate';
import { toast } from 'vue-sonner';
import * as z  from 'zod';


    useLoaderStore().hide();
    const formSchema = toTypedSchema(z.object({
        firstName: z.string().min(2).max(50),
        lastName: z.string().min(2).max(50),
        // birthDate: z.string(),
        // gender: z.string(),
    }));

    const { handleSubmit } = useForm({
        validationSchema: formSchema,
    })
    const onSubmit = handleSubmit((values) => {
    
        console.log(values);
        useLoaderStore().show();
        setTimeout(() => {
            useAuthStore().setRegisterPage('contact');
        }, 2000);
})
</script>