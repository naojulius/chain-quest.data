<template>
    <form class="w-full space-y-4" @submit="onSubmit">
        <FormField v-slot="{ componentField }" name="email">
            <FormItem>
                <FormControl>
                    <CommonInputsEmail v-bind="componentField" />
                </FormControl>
            </FormItem>
        </FormField>
        <button type="submit" class="w-full bg-gray-700 text-white h-14 rounded-full poppins-medium">
            Continuer
        </button>

        <!-- <div class="py-2">
            <Separator label="Ou" class="text-gray-700" />
        </div> -->
        <!-- <button type="button"
            class="w-full bg-white shadow-lg text-gray-700 h-14 rounded-full poppins-medium inline-flex items-center justify-between px-2">
            <img src="/icons/google.svg" class="size-8">
            <span>
                Continuer avec google
            </span>
            <ArrowRight class="size-8 text-gray-700" />
        </button>
        <button type="button"
            class="w-full bg-white shadow-lg text-gray-700 h-14 rounded-full poppins-medium inline-flex items-center justify-between px-2">
            <img src="/icons/qr-code.svg" class="size-8">
            <span>
                Continuer avec google
            </span>
            <ArrowRight class="size-8 text-gray-700" />
        </button> -->
    </form>
</template>
<script lang="ts" setup>
import { ArrowRight } from 'lucide-vue-next';
import { toTypedSchema } from '@vee-validate/zod';
import { useForm } from 'vee-validate';
import * as z from 'zod'
import { toast } from 'vue-sonner';

useLoaderStore().hide();
const formSchema = toTypedSchema(z.object({
    email: z.string().min(2).max(50),
}));

const { handleSubmit } = useForm({
    validationSchema: formSchema,
})

const onSubmit = handleSubmit((values) => {
    if(!useAuthStore().checkEmail(values.email)){
        toast("Erreur", {
            description: "Email non valide!",
            class: "text-lg"
        })
        return;
    }
    useLoaderStore().show();
    setTimeout(() => {
        useAuthStore().setRegisterPage('password');
    }, 2000);
})
</script>