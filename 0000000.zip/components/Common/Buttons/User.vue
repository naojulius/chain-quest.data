<script lang="ts" setup>
import { User2Icon} from 'lucide-vue-next';
</script>
<template>
    <button class="size-12 p-2 rounded-full text-gray-700">
        <User2Icon  class="size-full"/>
    </button>
</template>