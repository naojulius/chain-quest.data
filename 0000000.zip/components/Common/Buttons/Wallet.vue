<script lang="ts" setup>
    import { Wallet} from 'lucide-vue-next';
</script>
<template>
    <button class="size-12 p-2 rounded-full text-gray-700">
        <Wallet  class="size-full"/>
    </button>
</template>