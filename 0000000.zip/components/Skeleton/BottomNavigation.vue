<script lang="ts" setup>
import { Skeleton } from '@/components/ui/skeleton'
</script>
<template>
    <div class="h-20 w-full p-2 fixed bottom-0">
        <Skeleton class="size-full bg-gray-300 rounded-2xl inline-flex justify-between items-center px-1 "></Skeleton>
    </div>
</template>