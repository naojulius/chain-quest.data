<template>
     <div>
        <h1>Pool Details Page - ID: {{ $route.params.id }}</h1>
     </div>
</template>