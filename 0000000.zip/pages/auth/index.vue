<script lang="ts" setup>
definePageMeta({
    layout: 'auth'
});
</script>
<template>
    <component :is="useAuthStore().getPage.component"/>
</template>