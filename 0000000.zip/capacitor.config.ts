import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'e.zara.mg',
  appName: 'e-zara',
  webDir: '.output/public'
};

export default config;
