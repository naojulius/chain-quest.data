export const TEXT = {
    app_name: "E-Zara"
}