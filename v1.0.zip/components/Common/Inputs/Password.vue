<script lang="ts" setup>
useAuthStore().setPasswordButtonEyeclosed(false);
const props = defineProps({
  text: {
    required: true,
    type: String,
  },
})
</script>
<template>
    <div class="relative w-full">
        <input :type="useAuthStore().passwordButtonEyeclosed?'text':'password'" :placeholder="props.text" class="h-14 bg-gray-200 w-full rounded-full px-4 text-lg" />
        <CommonButtonsTogglePassword class="absolute right-0 top-1 mr-1" />
    </div>
</template>