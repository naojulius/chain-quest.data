<template>
    <div class="w-full">
        <input  autocomplete="off" type="text" :placeholder="props.placeholder" class="h-14 bg-gray-200 w-full rounded-full px-4 text-lg poppins-medium" />
    </div>
</template>
<script setup lang="ts">
const props = defineProps({
  placeholder: {
    required: true,
    type: String,
  },
})
</script>