<template>
    <div class="w-full inline-flex gap-0 items-center">
      <!-- Fixed Country Code -->
      <div
        class="text-lg text-gray-700 poppins-regular w-20 h-14 bg-gray-200 rounded-l-full border-r-gray-200 border-r-2 text-center flex items-center justify-center"
      >
        +261
      </div>
  
      <!-- Phone Number Input -->
      <input
        autocomplete="off"
        type="text"
        placeholder="XX XX XXX XX"
        class="h-14 bg-gray-200 w-full rounded-r-full px-4 text-lg poppins-medium placeholder-gray-500"
        :value="formattedPhone"
        @input="handleInput"
        maxlength="12"
      />
    </div>
  </template>
  
  <script setup lang="ts">
  import { ref, computed } from 'vue';
  
  // Store raw numbers (excluding spaces)
  const rawPhone = ref("");
  
  // Computed property for formatted display
  const formattedPhone = computed(() => {
    let digits = rawPhone.value.replace(/\D/g, ""); // Remove non-numeric characters
  
    // Limit max length (9 digits total)
    digits = digits.slice(0, 9);
  
    // Apply "XX XX XXX XX" format
    let formatted = `${digits.slice(0, 2)} ${digits.slice(2, 4)} ${digits.slice(4, 7)} ${digits.slice(7, 9)}`.trim();
  
    return formatted;
  });
  
  // Handle user input (only numbers allowed)
  const handleInput = (event: Event) => {
    const target = event.target as HTMLInputElement;
    rawPhone.value = target.value.replace(/\D/g, ""); // Keep only numbers
  };
  </script>
  