<template>
    <div class="w-full">
        <input pattern=".*" autocomplete="off" type="text" placeholder="Votre email" class="h-14 bg-gray-200 w-full rounded-full px-4 text-lg poppins-medium" />
    </div>
</template>