<script lang="ts" setup>
    import { Bell} from 'lucide-vue-next';
</script>
<template>
    <button class="size-12 p-2 rounded-full text-gray-700 relative">
        <Bell  class="size-full"/>
        <div class="size-3 bg-red-500 rounded-full absolute top-1 right-1"></div>
    </button>
</template>