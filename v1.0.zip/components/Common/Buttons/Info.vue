<script lang="ts" setup>
import { Info} from 'lucide-vue-next';
</script>
<template>
    <button class="size-12 p-2 rounded-full text-gray-700 bg-gray-200">
        <Info  class="size-full"/>
    </button>
</template>