<script setup lang="ts">
import { VisuallyHidden } from 'radix-vue'
import { ArrowLeft, Cog , BellRing} from 'lucide-vue-next'
import {
  Dialog,
  DialogContent,
  DialogTrigger,
  DialogDescription,
  DialogTitle,
} from '@/components/ui/dialog'
</script>
<style>
  #dialog-close{
    display: none !important;
  }
</style>
<template>
  <Dialog>
    <DialogTrigger as-child>
      <CommonButtonsBell />
    </DialogTrigger>
    <DialogContent class="h-full w-full">
      <VisuallyHidden>
        <DialogTitle></DialogTitle>
      </VisuallyHidden>
      <DialogDescription>
      <div class="flex flex-col gap-2  w-full h-full items-start">
        <div class="h-20 inline-flex justify-between items-center gap-2">
          <DialogClose as-child>
            <button>
                <ArrowLeft  class="size-8 text-gray-700"/>
            </button>
          </DialogClose>
          <span class="text-2xl text-gray-700 poppins-regular">Notifications</span>
        </div>
        <div class="h-full w-full flex flex-col gap-2 items-center justify-center">
          <BellRing class="text-gray-400 size-20"/>  
          <span class="poppins-regular text-xl text-center text-gray-400">
              Pas de notification le moments.
            </span>
        </div>
        <!-- <div class=" flex-col overflow-hidden p-1 border-b-2 bg-gray-100">
          <div class="inline-flex items-center justify-between w-full">
            <div class="inline-flex items-center gap-2">
              <Cog class="size-4" />
              <span>System</span>
            </div>
            <span>
              10h:20
            </span>
          </div>
          <div class="text-sm">Une connexion non identifie a ete detecte pres de nanisana</div>
        </div>
        <div class="flex-col overflow-hidden p-1 border-b-2 bg-gray-100">
          <div class="inline-flex items-center justify-between w-full">
            <div class="inline-flex items-center gap-2">
              <Cog class="size-4" />
              <span>System</span>
            </div>
            <span>
              10h:20
            </span>
          </div>
          <div class="text-sm">Une connexion non identifie a ete detecte pres de nanisana</div>
        </div> -->
      </div>
    </DialogDescription>
    </DialogContent>
  </Dialog>
</template>