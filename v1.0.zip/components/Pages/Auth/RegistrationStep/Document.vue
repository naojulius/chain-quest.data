<template>
    <form class="w-full space-y-4 relative h-full"  @submit="onSubmit">
            <div class="size-full flex flex-col gap-1">
                   <div class="overflow-hidden relative h-28 w-full bg-gray-700 rounded-2xl flex items-center justify-center text-white poppins-regular text-md">
                    
                        <div v-if="previewCinImageUrl" class="w-full h-full absolute top-0 left-0">
                            <img :src="previewCinImageUrl" alt="Image Preview" class="preview-image" />
                        </div>
                        <div class="w-full h-full absolute top-0 left-0 flex justify-center items-center">
                            <img  src="/icons/cloud.svg" class="size-32 opacity-30"/>
                        </div>
                        <div v-if="!previewCinImageUrl" class="w-full h-full absolute top-0 left-0 flex justify-center items-end">
                           CIN
                        </div>
                        
                        <input @change="onCinFileChange" accept="image/*" type="file" class="size-full absolute opacity-0" name="cin">
                   </div>
                   <div class="overflow-hidden relative h-28 w-full bg-gray-700 rounded-2xl flex items-center justify-center text-white poppins-regular text-md">
                    
                    <div v-if="previewResidenceImageUrl" class="w-full h-full absolute top-0 left-0">
                        <img :src="previewResidenceImageUrl" alt="Image Preview" class="preview-image" />
                    </div>
                    <div class="w-full h-full absolute top-0 left-0 flex justify-center items-center">
                        <img  src="/icons/cloud.svg" class="size-32 opacity-30"/>
                    </div>
                    <div v-if="!previewResidenceImageUrl" class="w-full h-full absolute top-0 left-0 flex justify-center items-end">
                       Certificat de residence
                    </div>
                    <input @change="onResidenceFileChange" accept="image/*" type="file" class="size-full absolute opacity-0">
               </div>
               <div class="overflow-hidden relative h-28 w-full bg-gray-700 rounded-2xl flex items-center justify-center text-white poppins-regular text-md">
                    
                    <div v-if="previewBulletinImageUrl" class="w-full h-full absolute top-0 left-0">
                        <img :src="previewBulletinImageUrl" alt="Image Preview" class="preview-image" />
                    </div>
                    <div class="w-full h-full absolute top-0 left-0 flex justify-center items-center">
                        <img  src="/icons/cloud.svg" class="size-32 opacity-30"/>
                    </div>
                    <div v-if="!previewBulletinImageUrl" class="w-full h-full absolute top-0 left-0 flex justify-center items-end">
                        Bulletin N 03
                    </div>
                    
                    <input @change="onBulletinFileChange" accept="image/*" type="file" class="size-full absolute opacity-0">
               </div>
                 
                <button type="submit" class="w-full bg-gray-700 text-white h-14 rounded-full poppins-medium absolute bottom-0">
                    Continuer
                    </button>
            </div>
        </form>
</template>
<script lang="ts" setup>
import { toTypedSchema } from '@vee-validate/zod';
import { useForm } from 'vee-validate';
import { toast } from 'vue-sonner';
import { Textarea } from '@/components/ui/textarea'
import * as z  from 'zod';

const previewCinImageUrl = ref<string | null>(null);
const previewResidenceImageUrl = ref<string | null>(null);
const previewBulletinImageUrl = ref<string | null>(null);

const onCinFileChange = (event: Event) => {

    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
    const file = input.files[0];
    previewCinImageUrl.value = URL.createObjectURL(file);
    }
};

const onResidenceFileChange = (event: Event) => {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
    const file = input.files[0];
    previewResidenceImageUrl.value = URL.createObjectURL(file);
    }
};

const onBulletinFileChange = (event: Event) => {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
    const file = input.files[0];
    previewBulletinImageUrl.value = URL.createObjectURL(file);
    }
};


    useLoaderStore().hide();
    const formSchema = toTypedSchema(z.object({
        
    }));

    const { handleSubmit } = useForm({
        validationSchema: formSchema,
    })
    const onSubmit = handleSubmit((values) => {
        useLoaderStore().show();
        setTimeout(() => {
            useAuthStore().setRegisterPage('about');
        }, 2000);
})
</script>