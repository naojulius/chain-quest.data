<template>
    <div class="w-full space-y-4 relative h-full">
        <div class="w-full h-full flex items-center justify-center">
            <PinInput
            id="pin-input"
            v-model="value"
            placeholder="○"
            @complete="handleComplete"
            >
            <PinInputGroup>
                <PinInputInput
                class="w-[60px] h-[60px] placeholder:text-gray-700 text-2xl poppins-regular"
                v-for="(id, index) in 5"
                :key="id"
                :index="index"
                />
            </PinInputGroup>
            </PinInput>
        </div>
            <button @click="next" type="button" class="w-full bg-gray-700 text-white h-14 rounded-full poppins-medium absolute bottom-0">
              Verifier
            </button>
        </div>
</template>
<script lang="ts" setup>
    import {
  PinInput,
  PinInputGroup,
  PinInputInput,
} from '@/components/ui/pin-input'
import { ref } from 'vue'
useLoaderStore().hide();
const value = ref<string[]>([])
const handleComplete = (e: string[]) => alert(e.join(''))
    
const next = () =>{
        useAuthStore().setRegisterPage('profile');
    }
</script>