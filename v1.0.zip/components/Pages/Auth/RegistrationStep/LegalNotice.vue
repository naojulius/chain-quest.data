<template>
    <form class="w-full space-y-4 relative h-full" @submit="onSubmit">
        <CommonAreaLegalNotice class="h-[50vh]" />
        <button type="submit" class="w-full bg-gray-700 text-white h-14 rounded-full poppins-medium absolute bottom-0">
              Accepter et Continuer
        </button>
        </form>
</template>
<script lang="ts" setup>
import { toTypedSchema } from '@vee-validate/zod';
import { useForm } from 'vee-validate';
import { toast } from 'vue-sonner';
import * as z  from 'zod';


    useLoaderStore().hide();
    const formSchema = toTypedSchema(z.object({
    }));

    const { handleSubmit } = useForm({
        validationSchema: formSchema,
    })
    const onSubmit = handleSubmit((values) => {
        useLoaderStore().show();
        setTimeout(() => {
            useAuthStore().acceptLegalNotice();
        }, 2000);
    
})
</script>