<template>
    <form class="w-full space-y-4 relative h-full" @submit="onSubmit">
        <div class="size-full flex flex-col gap-2 justify-center items-start">
            <div
                class="overflow-hidden relative h-60 w-full bg-gray-700 rounded-t-2xl flex items-center justify-center text-white poppins-regular text-md">

                <div v-if="previewImageUrl" class="w-full h-full absolute top-0 left-0">
                    <img :src="previewImageUrl" alt="Image Preview" class="preview-image" />
                </div>
                <div class="w-full h-full absolute top-0 left-0 flex justify-center items-center">
                    <img src="/icons/cloud.svg" class="size-40 opacity-30" />
                </div>
                <div v-if="!previewImageUrl" class="w-full h-full absolute top-0 left-0 flex justify-center items-end">
                    Cliquez pour telecharger votre photo
                </div>

                <input @change="onFileChange" accept="image/*" type="file" class="size-full absolute opacity-0">
            </div>
            <div class="h-full w-full">
                <FormField v-slot="{ componentField }" name="bio">
                    <FormItem>
                        <FormControl>
                            <Textarea v-bind="componentField"
                                class="w-full h-56 poppins-regular text-md  bg-gray-200 rounded-t-none"
                                placeholder="Ajouter votre bio ici." />
                        </FormControl>
                    </FormItem>
                </FormField>


            </div>
            <button type="submit"
                class="w-full bg-gray-700 text-white h-14 rounded-full poppins-medium absolute bottom-0">
                Continuer
            </button>
        </div>
    </form>
</template>
<script lang="ts" setup>
import { toTypedSchema } from '@vee-validate/zod';
import { useForm } from 'vee-validate';
import { toast } from 'vue-sonner';
import { Textarea } from '@/components/ui/textarea'
import * as z from 'zod';
const previewImageUrl = ref<string | null>(null);
const onFileChange = (event: Event) => {

    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
        const file = input.files[0];
        previewImageUrl.value = URL.createObjectURL(file);
    }
};


useLoaderStore().hide();
const formSchema = toTypedSchema(z.object({
    bio: z.string().min(1).max(150),
}));

const { handleSubmit } = useForm({
    validationSchema: formSchema,
})
const onSubmit = handleSubmit((values) => {
    useLoaderStore().show();
    setTimeout(() => {
        useAuthStore().setRegisterPage('document');
    }, 2000);
})
</script>