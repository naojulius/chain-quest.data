<script lang="ts" setup>
import { useAuthStore } from "~/stores/auth.store"
import { ArrowRight, ArrowLeft } from 'lucide-vue-next';
import {
  FormControl,
  FormField,
  FormItem,
} from '@/components/ui/form'
import { toTypedSchema } from "@vee-validate/zod";
import { useForm } from "vee-validate";
import * as z from "zod";
import { LoginReq } from "~/services/user/login-req.service";

const onNavigateBack = (page: string) => {
  useAuthStore().setPage(page);
}
const formSchema = toTypedSchema(z.object({
  email: z.string().min(2).max(50),
  password: z.string().min(2).max(50),
}));

const { handleSubmit } = useForm({
  validationSchema: formSchema,
})

const onSubmit = handleSubmit((values) => {
  console.log(values)
  useLoaderStore().show();
  setTimeout(() => {
    useAuthStore().login(new LoginReq());
  }, 2000);
})
</script>
<style></style>
<template>
  <div class="h-screen flex flex-col justify-start animate-fade-up animate-once animate-duration-75 bg-yellow-500">
    <div class="h-2/6 w-full flex flex-col px-4">
      <div class="h-20 inline-flex justify-between items-center">
        <button @click="onNavigateBack('index')">
          <ArrowLeft class="size-8 text-gray-700" />
        </button>
        <button @click="onNavigateBack('register')" class="text-lg poppins-regular text-gray-700 font-bold">
          Creez un compte
        </button>
      </div>
      <span class="text-3xl poppins-bold text-gray-700">
        Connexion
      </span>
      <span class="text-md poppins-regular font-bold text-gray-700 pt-4 pb-2 text-gray-700">
        Retrouvez votre trajet en un clic !
      </span>
    </div>
    <div class="h-full rounded-t-[40px] w-full bg-white p-6">
      <form class="w-full space-y-4" @submit="onSubmit">
        <FormField v-slot="{ componentField }" name="email">
          <FormItem>
            <FormControl>
              <CommonInputsEmail v-bind="componentField" placeholder="email" />
            </FormControl>
          </FormItem>
        </FormField>
        <FormField v-slot="{ componentField }" name="password">
          <FormItem>
            <FormControl>
              <CommonInputsPassword text="Mot de passe" v-bind="componentField" />
            </FormControl>
          </FormItem>
        </FormField>
        <div class="text-right pb-2 poppins-regular text-gray-700">
          Mots de passe oublie?
        </div>
        <button type="submit" class="w-full bg-gray-700 text-white h-14 rounded-full poppins-medium">
          Connexion
        </button>
        <!-- <div class="py-2">
                <Separator label="Ou" class="text-gray-700" />
            </div> -->
        <!-- <button type="button" class="w-full bg-white shadow-lg text-gray-700 h-14 rounded-full poppins-medium inline-flex items-center justify-between px-2">
                <img src="/icons/google.svg" class="size-8">
                <span>
                Continuer avec google
              </span>
              <ArrowRight  class="size-8 text-gray-700"/>
            </button>
            <button type="button" class="w-full bg-white shadow-lg text-gray-700 h-14 rounded-full poppins-medium inline-flex items-center justify-between px-2">
                <img src="/icons/qr-code.svg" class="size-8">
                <span>
                Continuer avec google
              </span>
              <ArrowRight  class="size-8 text-gray-700"/>
            </button> -->
      </form>
    </div>
  </div>
</template>