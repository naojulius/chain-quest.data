<template>
   <PagesHomeCarPool/>
</template>
<script setup lang="ts">
 useLoaderStore().hide();
</script>