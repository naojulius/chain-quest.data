<script lang="ts" setup>
import { LoaderCircle } from 'lucide-vue-next';
const carpooling = ref([])
</script>
<template>
    <div class="flex flex-col gap-4">
        <div class="bg-yellow-500 h-auto w-full rounded-2xl p-2">
            <div>
                <div class="text-lg text-gray-700 poppins-regular">Départ imminent, restez attentif !</div>
                <div class="text-3xl font-bold text-gray-700 py-4 poppins-bold">Co-Voiturage avec Randria et 2 autres personnes</div>
            </div>
            <div class="inline-flex items-center justify-between w-full">
                <div class="w-full text-xl font-bold text-gray-700 poppins-medium">
                    dans 30 mn
                </div>
                <div class="inline-flex items-center justify-end gap-2 w-full py-2">
                    <CommonButtonsPhone />
                    <CommonButtonsMessage />
                    <CommonButtonsInfo />
                </div>
            </div>
        </div>
    </div> 
    <!--<div class="h-[calc(100vh-11rem)]">
         <div class="size-full flex items-center flex-col justify-center">
            <span class="text-gray-500 text-2xl text-center font-bold py-4 poppins-bold">
                Vous n'avez pas de trajet pour le moment!
            </span>
            <div class="inline-flex justify-evenly items-center py-4 w-full gap-4">
                <button class="w-full bg-yellow-500 p-2 rounded-lg text-xl poppins-medium">
                    Chercher
                </button>
                <button class="w-full bg-gray-500  text-white p-2 rounded-lg text-xl poppins-medium">
                    Creer une
                </button>
            </div>
        </div> 
         <CommonLoaderInPage/> 
    </div>-->
</template>