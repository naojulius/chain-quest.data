<template>
    <div class="w-full rounded-xl overflow-hidden">
        <img src="/mocks/R.jpeg" alt="" class="size-full">
    </div>
    <div class="w-full h-20 flex items-center  justify-center gap-2">
        <Star class="fill-yellow-500 text-yellow-600 size-10" />
        <Star class="fill-yellow-500 text-yellow-600 size-10" />
        <Star class="fill-yellow-500 text-yellow-600 size-10" />
        <Star class="fill-yellow-500 text-yellow-600 size-10" />
        <Star class="fill-yellow-500 text-yellow-600 size-10" />
    </div>

    <div class="h-full w-full flex flex-col gap-2">
        <div class="w-full bg-gray-200 rounded-xl p-4">
            <div class="text-xl poppins-bold text-gray-700">Ride History & Stats</div>
            <div class="flex-col flex ">
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Rides completed</span>
                    <span class="poppins-regular text-xl">125</span>
                </div>
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Punctuality Score</span>
                    <span class="poppins-regular text-xl">95%</span>
                </div>
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Ride Acceptance Rate</span>
                    <span class="poppins-regular text-xl">95%</span>
                </div>
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Ride Cancellation Rate</span>
                    <span class="poppins-regular text-xl">5%</span>
                </div>
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Safety Score</span>
                    <span class="poppins-regular text-xl">100%</span>
                </div>
            </div>
        </div>
        <div class="w-full bg-gray-200 rounded-xl p-4">
            <div class="text-xl poppins-bold text-gray-700">Travel Policy</div>
            <div class="flex-col flex ">
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Pet Allowed</span>
                    <span class="poppins-regular text-xl">Yes</span>
                </div>
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Smoking Policy </span>
                    <span class="poppins-regular text-xl">Allowed</span>
                </div>
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Chat Preferences</span>
                    <span class="poppins-regular text-xl">Talkative</span>
                </div>
                <div class="py-1 inline-flex items-center justify-between w-full">
                    <span class="poppins-regular text-xl">Music Volume</span>
                    <span class="poppins-regular text-xl">Low</span>
                </div>
            </div>
        </div>
    </div>
</template>
<script lang="ts" setup>
import {
    Star
 } from 'lucide-vue-next';
</script>