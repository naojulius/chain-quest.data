<template>
    <div class="h-20 w-full p-2 fixed top-0 z-5 bg-white">
        <div class="h-full w-full inline-flex justify-between items-center">
            <Skeleton class="h-16 w-full bg-gray-300" />
        </div>
    </div>
</template>
<script setup lang="ts">
import { Skeleton } from '@/components/ui/skeleton'
</script>