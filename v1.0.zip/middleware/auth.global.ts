export default defineNuxtRouteMiddleware((to, from) => {
  const router = useRouter()
  let user = useCookie<{ id: number; name: string } | null>('user')
  if (!user.value && to.path !== '/auth') {
    //return navigateTo('/auth', { replace: true })
     router.push({ path: "/auth" })
  }

  if (user.value && to.path !== '/home') {
    router.push({ path: "/home" })
  }
})
